# ICE Test Framework

The goal of any automation (here Test Automation) is to reduce the manual effort of the repeated work cycles and thereby enhancing the individual to focus on other priority work items.

## Description

ICE Test Framework is a hybrid Testing Framework (Modular driven and Data driven) that tests various features aka functionalities along with the data. The functionalities of ICE leverages into 3 layers which are as follows:
1. **Application or Front End Layer** - Deals with the processing of chat, mobile, SMS, Instant messages etc., and provides different types of parsers to deal with the same like Cellebrite, Amazon slack, Slack JSON, Microsoft Teams, Chime and RSMF. Examples include: Universal Converter UI, Sightline etc.,
2. **Business Logic Layer** - Deals with processing of different types of data such as Word, PPT, ICS, XLS, Email, Outlook, Image, Video, Audio files etc., Examples include: ICE Console, Sightline to ICE API (SLICE API), ICE Actions API.
3. **Database or Back End Layer** - Deals with real processing of ICE data.


## Pre-Requisites
* Microsoft Visual Studio 2022

* Microsoft Windows 10 or higher versions

## Installation

Install the following packages along with their versions via nuget package manager tool available in Visual Studio 2022.
``` xml
<ItemGroup>
    <PackageReference Include="DotNetSeleniumExtras.PageObjects" Version="3.11.0" />
    <PackageReference Include="DotNetSeleniumExtras.PageObjects.Core" Version="4.0.1" />
    <PackageReference Include="ExtentReports.Core" Version="1.0.3" />
    <PackageReference Include="Ice.Sdk" Version="0.9.0-ICE-13015-sql-size-limit.1" />
    <PackageReference Include="Microsoft.NET.Test.Sdk" Version="16.11.0" />
    <PackageReference Include="Microsoft.SqlServer.SqlManagementObjects.SSMS" Version="161.47021.0" />
    <PackageReference Include="Microsoft.VisualStudio.Azure.Containers.Tools.Targets" Version="1.14.0" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.1" />
    <PackageReference Include="NUnit" Version="3.13.2" />
    <PackageReference Include="NUnit.Console" Version="3.15.0" />
    <PackageReference Include="NUnit3TestAdapter" Version="4.0.0" />
    <PackageReference Include="coverlet.collector" Version="3.1.0" />
    <PackageReference Include="RestSharp" Version="106.10.1" />
    <PackageReference Include="Selenium.Support" Version="4.1.0" />
    <PackageReference Include="Selenium.WebDriver" Version="4.1.0" />
    <PackageReference Include="Serilog" Version="2.10.0" />
    <PackageReference Include="Serilog.Formatting.Compact" Version="1.1.0" />
    <PackageReference Include="Serilog.Sinks.Console" Version="4.0.1" />
    <PackageReference Include="Serilog.Sinks.File" Version="5.0.0" />
    <PackageReference Include="System.Data.SqlClient" Version="4.8.3" />
    <PackageReference Include="WebDriverManager" Version="2.12.4" />
  </ItemGroup>
  ```
## Architectural Diagram of ICE Test Framework

![Architectural Diagram of ICE Test Framework](https://github.consilio.com/DiscoveryProcessing/ICE.TestFramework/blob/ICE-11094-framework-design/Images/Architecture_Diagram_Test_Framework.png "Ice Test Framework Architecture")

## ICE Test Framework Structure
ICE Test Framework design built using OOPS concepts and design patterns to make Framework more robust, reusable and readable.

ICE Test Framework supports plug and play if one wants to change the Framework or enhance the same.

ICE Test Framework is modularized into following to achieve the goal of the test automation:
1. Interfaces
2. Abstract or Implementable Classes
3. Pages
4. Serialization and Deserialization
5. Framework Settings
6. Logs for reporting
7. Test Scripts

Following image depicts the current ICE Test Framework structure:

![ICE Test Framework](https://github.consilio.com/DiscoveryProcessing/ICE.TestFramework/blob/ICE-11094-framework-design/Images/TestFramework_Folder_Structure.png "Ice Test Framework Structure")

## Description of the ICE Test Framework structure

#### Interfaces
Interfaces provides a way of communication to ICE engine via means of client sessions. With respect to ICE Test framework, there are 2 types of interfaces exist
1. API (REST APIs)
2. UI (Web application, ~~Desktop application~~)

API interface set of implementable HTTP methods which can be used to communicate with ICE API endpoints to do ICE processing or execution which are as follows:
* GET
* POST
* PUT
* DELETE

Small Snippet of code that shows the interface as follows:

```C# code
    internal interface IceAPIClient
    {
        public RestClient initializeEndpoint();
        public IRestRequest createGetRequest(string endPoint);
        public IRestRequest createPostRequest(string endPoint, string? jsonString = null);
        public IRestRequest createPutRequest(string endPoint, string? jsonString = null);
        public IRestRequest createPatchRequest(string endPoint, string? jsonString = null);
        public IRestRequest createDeleteRequest(string endPoint);
        public IRestResponse GetResponse(IRestClient restClient, IRestRequest restRequest);
    }
    internal interface UCUIClient
    {
        public WebDriver initBrowser();
    }
 ```

#### AbstractClasses

Abstract Classes implements the interface methods as of now supported in ICE Test Framework

Small snippet of code that implements the methods exposed by an interface as follows:
```C# code
    public class IceAPIAbstraction : IceAPIClient
    {
        IRestRequest IceAPIClient.createGetRequest(string endPoint)
        {
            return new RestRequest(endPoint, Method.GET)
                .AddHeader("Accept", "application/json");
        }
```

#### IceApiClasses

IceApiClasses defines classes for various API endpoints for Serialization and Deserialization of API requests and responses respectively.

Small snippet of code that implements the classes for Serialization and Deserialization as follows:
```C# code
    public class CustodianApiClass
    {
        public class Link
        {
            public string rel { get; set; }
            public string href { get; set; }
            public string action { get; set; }
        }

        public class GetCustodianApiClass
        {
            public int id { get; set; }
            public string name { get; set; }
            public List<Link> links { get; set; }
        }
    }
```

#### Pages

Pages implement page object model for Web UI , Database and ICE API endpoints. 
For Example - 
UCUIChimeJobPages.cs implements tasks like creation of new chime job, edit and save the settings of new chime job created and running the job untill it gets complete.
ICEProjectApiPages.cs implements methods for all the endpoints that Project resource provides such as GetAllProject Details, GetProjectDetails by its ID, Create a new project and Delete a project.
IceDbPages.cs implements the methods like executing SQL script, storing the result into text file in SqlResults folder and executing SQL stored procedure.

#### Logs (Reporting)

ICE Test Framework uses Serilog library for .Net logging of automation run. Also uses Extent .Net library for nice HTML reporting.
This folder gets created dynamically at run time and thus used for reporting purpose.

#### Settings

Settings  contains JSON formatted file with the environment related settings, UC Job related settings. JSON file provides user readability and easy manipulation of settings before automation run.

#### Tests

Tests contains the test scripts for executing the test cases related to ICE, API, UI and Database modules from end to end. 

Tests are written using Nunit Framework (based on .Net). Nunit framework provides QA team to easily integrate, run and debug the test scripts. Nunit also provides the following features:
* Attributes - To do One Time Setup/Teardown of the framework i.e., one time setup and teardown for automation, Categorizing the tests based on priorities, types (Smoke, Regression etc.,) and setup/teardown methods for individual tests or test suites.
* Assertions - To validate the test execution and accordingly update the result with PASS/Fail i.e.,assert the expected result matches with actual result.
* Runners - To run the whole automation suite or part of it via GUI Runner and Console Runner which makes QA member to easily run the automation.

Tests also contains Base Class (Initialize.cs) for Initialization and teardown of whole automation suite like initializing the API client session, UI client session, Database client session, configuring Serilog logging mechanism and configuring Extent HTML reporting. 

This Initization and teardown methods can be inherited or derived from the base class to all other tests thus maintaining one client session per each interface of automation. Teardown method deletes or destroys the client sessions once all the tests are run.

Snippet of small code that shows how the tests are written using Nunit Framework:
```C# Code
    [TestFixture]
    public class ExecuteDbTests : BaseTest
    {
        [Test]
        public void ExecuteScriptOnIceDb()
        {
            string sqlConnectionString = @"Data Source=LVSVTDUCSQL01;Initial Catalog=ICE000275;User ID=SD_EU_ICE;Password=puppy-chats-sally-K9";
            IceDbPage iceDbConnection = new IceDbPage(sqlConnectionString);
            try
            {
                string script = File.ReadAllText(System.IO.Directory.GetParent("../../../").FullName + "/SqlScripts/ICEQAReport.sql");
                iceDbConnection.executeSqlQueryWithOutput(script);
            }
            catch (Exception ex)
            {
                extentTest.Log(AventStack.ExtentReports.Status.Fail, "Failed due to " + ex.StackTrace);
                Assert.Fail(ex.Message);
            }
        }
    }
```

### Library

ICE Test Framework uses following libraries:
1. RestSharp --> For testing REST APIs in C#
2. Selenium  --> For testing Web UI in C#
3. SSMS      --> For testing Microsoft SQL database in C#
4. ICE SDK   --> For testing ICE Action APIs in C#

### How to run tests?

Tests can be run in the following ways:
1. Visual Studio Test Adapter - Right click on the [Test Fixture] or [Test] in the test file and select 'Run Tests'. Tests will start running and Test explorer window opens up to provide the provide the execution progress.

2. Nunit Console Runner - Download and Install Nunit3-Console runner. Open command prompt window, change the directory to Test automation folder. Using Nunit3-Console.exe file, point to the test automation class library (.dll) file to start test execution. By default all tests will start running when no test names provided as a parameter. We can provide list of tests or categories in a text file and provide the path of the text file to start test execution. Sample Example as given below:
``` command
C:\Users\guru.matam\source\repos\IceTestAutomation\bin\Debug\net6.0>C:\Users\guru.matam\Nunit3-Console\bin\net6.0\nunit3-console.exe --testlist=tests.txt IceTestAutomation.dll
```
Refer the [link](https://docs.nunit.org/articles/nunit/running-tests/Console-Command-Line.html) for running the tests with the command line options provided for execution.

### Demo Recording
Test Automation Framework Demo can be found at the [link](https://consilious.sharepoint.com/tech/eng/productdevelopment/Product%20Development%20Status/Forms/AllItems.aspx?csf=1&web=1&e=1pkZbX&cid=8b7ef8a5%2D889b%2D4bca%2Db7df%2D789df807ce2a&FolderCTID=0x012000E223951DB1E0DB4081A196712349B809&id=%2Ftech%2Feng%2Fproductdevelopment%2FProduct%20Development%20Status%2FICE%2FMeeting%20Recordings%20and%20Demos%2FVideo%20Demos%20and%20Training%2FQA%20Training%2FICE%2DTestAutomation%2DFramework&viewid=eb113381%2De1aa%2D4a07%2D9214%2D519de95f6f18)

### FAQs

1. Where do I get ICE SDK?  
---> https://github.consilio.com/DiscoveryProcessing/Ice.Sdk  
2. Why ICE Console application not automated?  
---> Desktop Automation can be done via WinAppDriver, this is parked as of now and will be taken in near future

### References
[ICE SDK](https://github.consilio.com/DiscoveryProcessing/Ice.Sdk)  
[Nunit Framework](NUnit.org)  
[RestSharp](https://restsharp.dev)  
[Selenium](https://www.selenium.dev)  
[Rock Solid Automation Blog](https://blog.testproject.io/2019/04/23/rock-solid-test-automation)  
[Lean Test Automation Blog](http://www.eliasnogueira.com/basic-explanation-lean-web-test-automation-architecture/)

