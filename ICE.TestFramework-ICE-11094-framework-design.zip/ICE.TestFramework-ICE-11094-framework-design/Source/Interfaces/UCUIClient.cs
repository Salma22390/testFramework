﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceTestAutomation.Interfaces
{
    /// <summary>
    /// UCUIClient - An UC UI interface that exposes browser client session to the user.
    /// </summary>
    internal interface UCUIClient
    {
        public WebDriver initBrowser();
    }
}
