﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceTestAutomation.Interfaces
{
    /// <summary>
    /// IceAPIClient - An interface that exposes below methods to client API sessions.
    /// </summary>
    internal interface IceAPIClient
    {
        public RestClient initializeEndpoint();
        public IRestRequest createGetRequest(string endPoint);
        public IRestRequest createPostRequest(string endPoint, string? jsonString = null);
        public IRestRequest createPutRequest(string endPoint, string? jsonString = null);
        public IRestRequest createPatchRequest(string endPoint, string? jsonString = null);
        public IRestRequest createDeleteRequest(string endPoint);
        public IRestResponse GetResponse(IRestClient restClient, IRestRequest restRequest);
    }
}
