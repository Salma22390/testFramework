/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using Serilog;
using Serilog.Core;
using Serilog.Events;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using System.IO;
using System;
using Serilog.Sinks.SystemConsole.Themes;

namespace IceTestAutomation.Utilities
{
    public  class IceLogger
    {
        
        private static AventStack.ExtentReports.ExtentReports? extent;
        private static ExtentTest? test;
        private static ILogger? _serilogLogger;
        public static System.IO.DirectoryInfo? parentPath = System.IO.Directory.GetParent("../../../");
        public static string? projectPath = parentPath.FullName;
        public static string? reportPath = projectPath + Path.DirectorySeparatorChar + "Logs"
                                        + Path.DirectorySeparatorChar + "Logs_" + DateTime.Now.ToString("ddMMyyyy HHmmss");
        public static void Initialize()
        {
            string outputTemplate = "[{Timestamp:yyyy-MM-dd HH:mm:ss.fff}] {SourceContext}{Message}{NewLine}";
            LoggingLevelSwitch levelSwitch = new LoggingLevelSwitch(LogEventLevel.Information);
            _serilogLogger = new LoggerConfiguration()
                                .MinimumLevel.ControlledBy(levelSwitch)
                                .WriteTo.Console(LogEventLevel.Warning, outputTemplate, theme: AnsiConsoleTheme.Literate)
                                .Enrich.FromLogContext()
                                .WriteTo.File(reportPath + @"\Logs.txt",
                                outputTemplate: outputTemplate,
                                rollingInterval: RollingInterval.Day).CreateLogger();
                                
            extent = new AventStack.ExtentReports.ExtentReports();
            ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(reportPath + "\\Automation_Report" + ".html");
            htmlReporter.LoadConfig(projectPath  + "/Settings/htmlReport-Config.xml");
            extent.AttachReporter(htmlReporter);
        }

        public static ExtentTest StartTest(string testName)
        {
            test = extent.CreateTest(testName);
            return test;
        }

        public static void LogInformation(string message)
        {
            _serilogLogger.Information(message);
            test.Log(Status.Info, message);
        }

        public static void LogError(string message, Exception ex = null)
        {
            _serilogLogger.Error(ex, message);
            test.Log(Status.Fail, message + (ex != null ? $"\n\n{ex}" : ""));
        }

        public static void EndTest()
        {
            extent.Flush();
        }
    }
}
