﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceTestAutomation.Utilities
{
    public class AppSettings
    {
        public string IceAPIUrl { get; set; }
        public string HostName { get; set; }
        public string DatabaseName { get; set; }
        public string DatasetUncPath { get; set; }
        public string ExportPath { get; set; }
        public ProjectsURI ProjectsURI { get; set; }
        public string InfoURI { get; set; }
    }
    public class ProjectsURI
    {
        public string GetPostURI { get; set; }
        public string GetWorkflowsURI { get; set; }
    }

   
}
