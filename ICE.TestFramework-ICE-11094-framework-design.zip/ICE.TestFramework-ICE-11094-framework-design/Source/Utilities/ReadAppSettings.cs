﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace IceTestAutomation.Utilities
{
    class ReadAppSettings
    {
        AppSettings _config;

        static string appSettingsPath = System.IO.Directory.GetParent("../../../").FullName + "/Settings/appsettings.json";

        public ReadAppSettings()
        {
            _config = GetAppSettings();
        }

        public AppSettings GetAppSettings()
        {
            string jsonString = File.ReadAllText(appSettingsPath);
            AppSettings appSettings = JsonSerializer.Deserialize<AppSettings>(jsonString);

            return appSettings;
        }
    }
}
