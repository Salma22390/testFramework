﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.IceActionApiModels
{
    public record CentralRepository(
        [property: JsonPropertyName("key")] string Key,
        [property: JsonPropertyName("value")] string Value
    );
}
