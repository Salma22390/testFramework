﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.IceActionApiModels
{
    public record Custodians(
        [property: JsonPropertyName("id")] int? Id,
        [property: JsonPropertyName("name")] string Name
    );

    public record CustomProperty(
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("value")] string Value
    );

    public record SourceDataSets(
        [property: JsonPropertyName("additionalProp1")] int? AdditionalProp1,
        [property: JsonPropertyName("additionalProp2")] int? AdditionalProp2,
        [property: JsonPropertyName("additionalProp3")] int? AdditionalProp3
    );

    public record Extended(
        [property: JsonPropertyName("header")] Header Header,
        [property: JsonPropertyName("sourceIsCompressed")] int? SourceIsCompressed,
        [property: JsonPropertyName("description")] string Description,
        [property: JsonPropertyName("validDateRange")] ValidDateRange ValidDateRange,
        [property: JsonPropertyName("customProperties")] IReadOnlyList<CustomProperty> CustomProperties
    );

    public record Header(
        [property: JsonPropertyName("createdFrom")] string CreatedFrom,
        [property: JsonPropertyName("createdBy")] string CreatedBy,
        [property: JsonPropertyName("createdOnUtc")] DateTime? CreatedOnUtc
    );

    public record Root(
        [property: JsonPropertyName("id")] int? Id,
        [property: JsonPropertyName("uid")] string Uid,
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("path")] string Path,
        [property: JsonPropertyName("status")] string Status,
        [property: JsonPropertyName("datasets")] SourceDataSets Datasets,
        [property: JsonPropertyName("custodian")] Custodians Custodian,
        [property: JsonPropertyName("priority")] int? Priority,
        [property: JsonPropertyName("itemCount")] int? ItemCount,
        [property: JsonPropertyName("extended")] Extended Extended
    );

    public record ValidDateRange(
        [property: JsonPropertyName("start")] DateTime? Start,
        [property: JsonPropertyName("end")] DateTime? End
    );
}
