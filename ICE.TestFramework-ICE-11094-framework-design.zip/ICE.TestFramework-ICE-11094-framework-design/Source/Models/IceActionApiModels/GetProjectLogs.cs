﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.IceActionApiModels
{
    public record Entry(
        [property: JsonPropertyName("category")] string Category,
        [property: JsonPropertyName("id")] int? Id,
        [property: JsonPropertyName("timestamp")] DateTime? Timestamp,
        [property: JsonPropertyName("typeId")] int? TypeId,
        [property: JsonPropertyName("message")] string Message,
        [property: JsonPropertyName("host")] string Host,
        [property: JsonPropertyName("user")] string User,
        [property: JsonPropertyName("source")] string Source
    );

    public record GetProjectLogs(
        [property: JsonPropertyName("entries")] IReadOnlyList<Entry> Entries,
        [property: JsonPropertyName("maxEventId")] int? MaxEventId,
        [property: JsonPropertyName("maxErrorId")] int? MaxErrorId
    );
}
