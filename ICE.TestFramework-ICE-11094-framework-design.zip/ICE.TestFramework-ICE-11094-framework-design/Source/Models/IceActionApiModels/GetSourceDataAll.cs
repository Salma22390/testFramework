﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.IceActionApiModels
{
    // Root myDeserializedClass = JsonSerializer.Deserialize<Root>(myJsonResponse);
    public record Custodian(
        [property: JsonPropertyName("id")] int? Id,
        [property: JsonPropertyName("name")] string Name
    );

    public record Datasets(
        [property: JsonPropertyName("additionalProp1")] int? AdditionalProp1,
        [property: JsonPropertyName("additionalProp2")] int? AdditionalProp2,
        [property: JsonPropertyName("additionalProp3")] int? AdditionalProp3
    );

    public record SourceData(
        [property: JsonPropertyName("id")] int? Id,
        [property: JsonPropertyName("uid")] string Uid,
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("path")] string Path,
        [property: JsonPropertyName("status")] string Status,
        [property: JsonPropertyName("datasets")] Datasets Datasets,
        [property: JsonPropertyName("custodian")] Custodian Custodian,
        [property: JsonPropertyName("priority")] int? Priority
    );

    public record GetSourceDataAll(
        [property: JsonPropertyName("data")] IReadOnlyList<SourceData> Data,
        [property: JsonPropertyName("page")] int? Page,
        [property: JsonPropertyName("offset")] int? Offset,
        [property: JsonPropertyName("total")] int? Total
    );


}
