﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.IceActionApiModels
{
    public record Datum(
        [property: JsonPropertyName("id")] string Id,
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("description")] string Description,
        [property: JsonPropertyName("created")] DateTime? Created,
        [property: JsonPropertyName("sourceIceVersion")] string SourceIceVersion,
        [property: JsonPropertyName("fieldCount")] int? FieldCount
    );

    public record FieldsetAll(
        [property: JsonPropertyName("data")] IReadOnlyList<Datum> Data,
        [property: JsonPropertyName("page")] int? Page,
        [property: JsonPropertyName("offset")] int? Offset,
        [property: JsonPropertyName("total")] int? Total
    );


}
