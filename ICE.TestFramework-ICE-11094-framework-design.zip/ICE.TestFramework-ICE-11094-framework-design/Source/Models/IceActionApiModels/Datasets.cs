﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.IceActionApiModels
{
    public record Dataset(
        [property: JsonPropertyName("id")] int? Id,
        [property: JsonPropertyName("uid")] string Uid,
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("description")] string Description,
        [property: JsonPropertyName("statusName")] string StatusName,
        [property: JsonPropertyName("createdFrom")] string CreatedFrom,
        [property: JsonPropertyName("createdBy")] string CreatedBy,
        [property: JsonPropertyName("createdOnUtc")] DateTime? CreatedOnUtc,
        [property: JsonPropertyName("groupName")] string GroupName,
        [property: JsonPropertyName("sourceExhibitList")] IReadOnlyList<int?> SourceExhibitList
    );

    public record DatasetsList(
        [property: JsonPropertyName("datasets")] IReadOnlyList<Dataset> Datasets
    );


}
