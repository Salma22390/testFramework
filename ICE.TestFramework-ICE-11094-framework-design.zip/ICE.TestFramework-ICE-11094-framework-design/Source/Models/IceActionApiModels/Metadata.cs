﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.IceActionApiModels
{
    public record Fields(
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("value")] string Value,
        [property: JsonPropertyName("dataType")] string DataType
    );

    public record Item(
        [property: JsonPropertyName("exportOrderId")] int? ExportOrderId,
        [property: JsonPropertyName("itemUid")] string ItemUid,
        [property: JsonPropertyName("parentUid")] string ParentUid,
        [property: JsonPropertyName("topParentUid")] string TopParentUid,
        [property: JsonPropertyName("itemId")] int? ItemId,
        [property: JsonPropertyName("fileMd5")] string FileMd5,
        [property: JsonPropertyName("fileSignature")] string FileSignature,
        [property: JsonPropertyName("class")] string Class,
        [property: JsonPropertyName("depth")] int? Depth,
        [property: JsonPropertyName("fields")] IReadOnlyList<Fields> Fields
    );

    public record Metadata(
        [property: JsonPropertyName("page")] int? Page,
        [property: JsonPropertyName("pageSize")] int? PageSize,
        [property: JsonPropertyName("count")] int? Count,
        [property: JsonPropertyName("total")] int? Total,
        [property: JsonPropertyName("items")] IReadOnlyList<Item> Items
    );
}
