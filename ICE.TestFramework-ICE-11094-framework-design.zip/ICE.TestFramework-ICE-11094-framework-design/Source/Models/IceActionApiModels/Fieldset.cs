﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.IceActionApiModels
{
    public record Field(
        [property: JsonPropertyName("order")] int? Order,
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("dataType")] string DataType,
        [property: JsonPropertyName("displayName")] string DisplayName,
        [property: JsonPropertyName("description")] string Description
    );

    public record FieldCollection(
        [property: JsonPropertyName("schema")] string Schema,
        [property: JsonPropertyName("source")] string Source,
        [property: JsonPropertyName("sourceType")] string SourceType,
        [property: JsonPropertyName("key")] string Key,
        [property: JsonPropertyName("sourceDescription")] string SourceDescription,
        [property: JsonPropertyName("fields")] IReadOnlyList<Field> Fields
    );

    public record FieldSet(
        [property: JsonPropertyName("id")] string Id,
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("description")] string Description,
        [property: JsonPropertyName("created")] DateTime? Created,
        [property: JsonPropertyName("sourceIceVersion")] string SourceIceVersion,
        [property: JsonPropertyName("fieldCollections")] IReadOnlyList<FieldCollection> FieldCollections
    );


}
