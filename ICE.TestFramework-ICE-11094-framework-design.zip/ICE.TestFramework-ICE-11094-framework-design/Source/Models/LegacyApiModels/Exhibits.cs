﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.LegacyApiModels
{
    public record Link(
        [property: JsonPropertyName("rel")] string Rel,
        [property: JsonPropertyName("href")] string Href,
        [property: JsonPropertyName("action")] string Action
    );

    public record Exhibits(
        [property: JsonPropertyName("links")] IReadOnlyList<Link> Links,
        [property: JsonPropertyName("id")] int? Id,
        [property: JsonPropertyName("uid")] string Uid,
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("description")] string Description,
        [property: JsonPropertyName("uncPath")] string UncPath,
        [property: JsonPropertyName("status")] string Status,
        [property: JsonPropertyName("custodianId")] int? CustodianId,
        [property: JsonPropertyName("custodianName")] string CustodianName,
        [property: JsonPropertyName("createdFrom")] string CreatedFrom,
        [property: JsonPropertyName("createdBy")] string CreatedBy,
        [property: JsonPropertyName("createdOnUtc")] DateTime? CreatedOnUtc,
        [property: JsonPropertyName("validDateRangeStart")] DateTime? ValidDateRangeStart,
        [property: JsonPropertyName("validDateRangeEnd")] DateTime? ValidDateRangeEnd,
        [property: JsonPropertyName("settings")] Settings Settings
    );

    public record Settings(
        [property: JsonPropertyName("additionalProp1")] string AdditionalProp1,
        [property: JsonPropertyName("additionalProp2")] string AdditionalProp2,
        [property: JsonPropertyName("additionalProp3")] string AdditionalProp3
    );


}
