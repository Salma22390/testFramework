﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.LegacyApiModels
{
    public record Entity(
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("identifier")] string Identifier,
        [property: JsonPropertyName("type")] string Type,
        [property: JsonPropertyName("ownerFieldType")] int? OwnerFieldType,
        [property: JsonPropertyName("uid")] string Uid,
        [property: JsonPropertyName("source")] string Source,
        [property: JsonPropertyName("sourceOffset")] int? SourceOffset,
        [property: JsonPropertyName("tag")] IReadOnlyList<Tag> Tag,
        [property: JsonPropertyName("creationDateTime")] DateTime? CreationDateTime,
        [property: JsonPropertyName("creationTime")] string CreationTime,
        [property: JsonPropertyName("lastModifiedDateTime")] DateTime? LastModifiedDateTime,
        [property: JsonPropertyName("lastModifiedTime")] string LastModifiedTime
    );

    public record Generatated(
        [property: JsonPropertyName("createdUtc")] DateTime? CreatedUtc,
        [property: JsonPropertyName("sourceItemId")] int? SourceItemId,
        [property: JsonPropertyName("taskName")] string TaskName
    );

    public record Custodians(
        [property: JsonPropertyName("id")] int? Id,
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("xml")] Xml Xml,
        [property: JsonPropertyName("priority")] int? Priority
    );

    public record Tag(
        [property: JsonPropertyName("tagName")] string TagName,
        [property: JsonPropertyName("tagDataType")] string TagDataType,
        [property: JsonPropertyName("tagValue")] string TagValue
    );

    public record Xml(
        [property: JsonPropertyName("description")] string Description,
        [property: JsonPropertyName("generatated")] Generatated Generatated,
        [property: JsonPropertyName("entity")] IReadOnlyList<Entity> Entity,
        [property: JsonPropertyName("tag")] IReadOnlyList<Tag> Tag
    );
}