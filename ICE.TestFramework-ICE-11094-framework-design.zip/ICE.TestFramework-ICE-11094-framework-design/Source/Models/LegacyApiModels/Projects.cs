﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.LegacyApiModels
{
    public record Projects(
        [property: JsonPropertyName("id")] int? Id,
        [property: JsonPropertyName("uid")] string Uid,
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("databaseName")] string DatabaseName,
        [property: JsonPropertyName("description")] string Description,
        [property: JsonPropertyName("createdOnUtc")] DateTime? CreatedOnUtc,
        [property: JsonPropertyName("createdFrom")] string CreatedFrom,
        [property: JsonPropertyName("createdBy")] string CreatedBy,
        [property: JsonPropertyName("number")] string Number,
        [property: JsonPropertyName("client")] string Client,
        [property: JsonPropertyName("workflow")] string Workflow,
        [property: JsonPropertyName("jobCount")] int? JobCount,
        [property: JsonPropertyName("lastOpenedBy")] string LastOpenedBy,
        [property: JsonPropertyName("lastOpenedOnUtc")] DateTime? LastOpenedOnUtc,
        [property: JsonPropertyName("lastUpdatedBy")] string LastUpdatedBy,
        [property: JsonPropertyName("lastUpdatedOnUtc")] DateTime? LastUpdatedOnUtc,
        [property: JsonPropertyName("enableZantazFieldsDetection")] bool? EnableZantazFieldsDetection,
        [property: JsonPropertyName("enableNuixProcessing")] bool? EnableNuixProcessing,
        [property: JsonPropertyName("timeZoneId")] string TimeZoneId,
        [property: JsonPropertyName("mirroringPath")] string MirroringPath,
        [property: JsonPropertyName("enableOcr")] bool? EnableOcr,
        [property: JsonPropertyName("enableVirusScanning")] bool? EnableVirusScanning,
        [property: JsonPropertyName("enablePdfRendering")] bool? EnablePdfRendering
    );
}