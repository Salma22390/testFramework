﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.LegacyApiModels
{
    public record Links(
        [property: JsonPropertyName("rel")] string Rel,
        [property: JsonPropertyName("href")] string Href,
        [property: JsonPropertyName("action")] string Action
    );

    public record Datasets(
        [property: JsonPropertyName("links")] IReadOnlyList<Links> Links,
        [property: JsonPropertyName("id")] int? Id,
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("description")] string Description,
        [property: JsonPropertyName("status")] string Status,
        [property: JsonPropertyName("createdFrom")] string CreatedFrom,
        [property: JsonPropertyName("createdBy")] string CreatedBy,
        [property: JsonPropertyName("createdOnUtc")] DateTime? CreatedOnUtc,
        [property: JsonPropertyName("groupName")] string GroupName,
        [property: JsonPropertyName("sourceExhibitList")] IReadOnlyList<int?> SourceExhibitList
    );
}
