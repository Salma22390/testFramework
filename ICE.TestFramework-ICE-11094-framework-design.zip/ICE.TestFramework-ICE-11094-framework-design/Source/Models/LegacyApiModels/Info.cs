﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace IceTestAutomation.Models.LegacyApiModels
{
    public record Info(
        [property: JsonPropertyName("component")] string Component,
        [property: JsonPropertyName("version")] string Version,
        [property: JsonPropertyName("versionInformational")] string VersionInformational,
        [property: JsonPropertyName("buildDate")] string BuildDate
    );


}
