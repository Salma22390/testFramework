﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using AventStack.ExtentReports;
using Ice.Sdk;
using Ice.Sdk.Models;
using Ice.Sdk.OpenApi;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using IceTestAutomation.Utilities;

namespace IceTestAutomation.Tests.IceApiTests
{
    /// <summary>
    /// Test Suite for ICE-9777 SQL Backup API tests
    /// </summary>
    [TestFixture]
    public class IceSqlRestoreTests : BaseTest
    {
        private readonly IIceConnectorRepository? _iceConnectorRepository;

        [Test]
        [TestCase("MTPCTSDEV02370", @"\\hlnas01\data\Benchmark\Guru_Backup\01\archive\ICE000002\ff8022c0-cddd-40c7-a3a0-07ffe1183aa1.icebk",@"\\hlnas01\data\Benchmark\Guru_Backup\02\archive\ICE000003\23eb362b-9b8e-42f2-a5ea-8f7a6f431045.icebk")]
        public async Task IceCreateBackupAsync(string hostName, string backUpPath1, string backUpPath2)
        {
            try
            {
               
                var token = new CancellationToken();
                var cancellationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(token);
                var httpClient = new HttpClient();
                var ice = new IceConnector(iceApiHost: hostName, port: 4080, httpClient);
                var progress = new Progress<BackgroundJobProgress>();
                ICollection<string> backUpPathList = new List<string>{backUpPath1, backUpPath2};
                var restoreOptions = new RestoreBackupRequest{TargetSqlInstance=@$"{hostName}\sqlexpress",BackupFiles=backUpPathList.ToArray<string>()};
                var restoreJob = await ice.CreateRestoreBackupRemoteAsync(restoreOptions, cancellationTokenSource.Token);
                
                progress.ProgressChanged += ReportProgress2;
                IceLogger.LogInformation("RestoreJob Details " + $"{restoreJob}");
                await ice.MonitorJobStatusAsync(restoreJob, progress, cancellationTokenSource.Token);
                progress.ProgressChanged -= ReportProgress2;
            }
            catch (Exception e)
            {
                IceLogger.LogError("Failed due to exception: " + e.Message);
                Assert.Fail();
            }
        }

        private void ReportProgress(object? sender, ProgressReport e)
        {
            switch (e.Message)
            {
                case null:
                case "":
                    IceLogger.LogInformation("Status of Restore Job " + $"{DateTime.UtcNow:HH:mm:ss.ff} {e.Message}/{e.Progress}");
                    break;
                default:
                    IceLogger.LogInformation("Status of restore job " + $"{DateTime.UtcNow:HH:mm:ss.ff} {e.Message}/{e.Progress} - {e.Message}");
                    break;
            }

        }

      private void ReportProgress2(object? sender, BackgroundJobProgress e)
        {
            switch (e.Message)
            {
                case null:
                case "":
                    IceLogger.LogInformation("Restore Job Status " +  $"{DateTime.UtcNow:HH:mm:ss.ff} {e.Id}/{e.Status}");
                    break;
                default:
                    IceLogger.LogInformation("Restore Job Status " +  $"{DateTime.UtcNow:HH:mm:ss.ff} {e.Id}/{e.Status} - {e.Message}");
                    break;
            }

        }
    }
}
