﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Ice.Sdk;
using System.Net.Http;
using System.Threading;
using Ice.Sdk.Models;
using System.IO;
using Ice.Sdk.OpenApi;
using IceTestAutomation.Utilities;

namespace IceTestAutomation.Tests.IceApiTests
{

    /// <summary>
    /// IceSdkTests - Test suite for Ice API v2 (Action APIs) SDK.
    /// </summary>
    [TestFixture]
    public class IceSdkTests : BaseTest
    {
        [Test]
        //[Parallelizable(ParallelScope.Children)]
        [TestCase("MTPCTSDEV02390", @"\\hlnas01\data\Benchmark\Guru_Backup\01\archive", @"\\hlnas01\data\Benchmark\Guru_Backup\01", "Test1")]
        [TestCase("LVSVUANUX05", @"\\hlnas01\data\Benchmark\Guru_Backup\03\archive", @"\\hlnas01\data\Benchmark\Guru_Backup\03", "Test3")]
        public async Task IceSdkTest001Async(string hostName, string archivePath, string MirroringPath, string testName)
        {
            try
            {

                var token = new CancellationToken();
                var cancellationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(token);
                var httpClient = new HttpClient();
                var ice = new IceConnector(iceApiHost: hostName, port: 4080, httpClient);
                var progress = new Progress<ProgressReport>();
                List<ProjectOCRLanguage> ocrLangList = new List<ProjectOCRLanguage> { OcrLanguage.German, OcrLanguage.Japanese, OcrLanguage.Korean, OcrLanguage.English };
                OcrOptions occrOpts = new OcrOptions { EnableOcr = false, OcrLanguages = ocrLangList };
                var iceDatasetInput = new IceConnectorCreateDatasetInput
                {
                    HCode = testName,
                    MediaId = "A001",
                    CustodianId = "TestAutomation",
                    SourcePath = new DirectoryInfo(@"\\hlnas01\data\Benchmark\Source_Data\Reference_Datasets\MetaDataCompare\SET 07 - ICS"),
                    ArchiveDirectory = new DirectoryInfo(archivePath),
                    MirroringPath = new DirectoryInfo(MirroringPath),
                    Workflow = ProjectWorkflowEnum.Doc,
                    EnableNuixProcessing = false,
                    EnablePdfRendering = true,
                    EnableVirusScanning = false,
                    //PathPrefix = "\\SET 2 - Loose eMails\\Folder1",
                    TimezoneId = "Hawaiian Standard Time",
                    OcrOptions = occrOpts
                };

                progress.ProgressChanged += ReportProgress;

                //create case and add data.
                var iceDataset = await ice.CreateDatasetAsync(iceDatasetInput, progress: progress, cancellationToken: cancellationTokenSource.Token);

                IceLogger.LogInformation($"Created Ice Dataset: {iceDataset}");
                progress.ProgressChanged -= ReportProgress;

                //request processing.
                var iceDatasetProcessing = await ice.StartProcessingAsync(iceDataset, cancellationToken: cancellationTokenSource.Token);

                IceLogger.LogInformation( $"{testName} Processing Ice Dataset: {iceDatasetProcessing}");
                //poll metrics.

                var processingProgress = new Progress<IceSdkProgressReport>();
                processingProgress.ProgressChanged += ReportProgress2;
                IceLogger.LogInformation($"{testName} Monitoring Processing of exhibit - Started at {DateTime.UtcNow:HH:mm:ss.ff}");
                var processed = await ice.MonitorProcessingAsync(iceDatasetProcessing, processingProgress, cancellationToken: cancellationTokenSource.Token);
                IceLogger.LogInformation($"{testName} Processing Status - " + processed.Status );
                processingProgress.ProgressChanged -= ReportProgress2;
                IceLogger.LogInformation($"{testName} Processing is Complete - Now Ready for Filtering and Export in {DateTime.UtcNow:HH:mm:ss.ff} {processed.Instance}#{processed.ProjectId}.Export:{processed.DefaultExportDataset}");
            }
            catch (Exception e)
            {
                IceLogger.LogError("Test Failed due to error: " + e.Message);
                Assert.Fail();
            }
        }

        /// <summary>
        /// ReportProgress2() - To know the progress of project cracking
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReportProgress2(object? sender, IceSdkProgressReport e)
        {
            foreach (var l in e.Log)
            {
                IceLogger.LogInformation($"{l.Timestamp:HH:mm:ss.ff} {TestContext.CurrentContext.Test.Name} {l.Category} {l.Message}");
            }
        }

        /// <summary>
        /// ReportProgress() - To know the progress of project creation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReportProgress(object? sender, ProgressReport e)
        {
            switch (e.Message)
            {
                case null:
                case "":
                    IceLogger.LogInformation($"{DateTime.UtcNow:HH:mm:ss.ff} {e.Progress}/{e.Total}");
                    break;
                default:
                    IceLogger.LogInformation($"{DateTime.UtcNow:HH:mm:ss.ff} {TestContext.CurrentContext.Test.Name} {e.Progress}/{e.Total} - {e.Message}");
                    break;
            }

        }
    }
}