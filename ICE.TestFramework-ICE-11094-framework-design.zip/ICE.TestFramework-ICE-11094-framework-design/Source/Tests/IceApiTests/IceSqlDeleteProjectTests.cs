﻿using Ice.Sdk;
using System;
using System.Threading.Tasks;
using NUnit.Framework;
using AventStack.ExtentReports;
using System.Net.Http;
using System.Threading;
using Ice.Sdk.Models;
using IceTestAutomation.Utilities;
using NUnit.Framework.Interfaces;

namespace IceTestAutomation.Tests.IceApiTests
{
    [TestFixture]
    public class IceSqlDeleteProjectTests : BaseTest
    {
        private readonly IIceConnectorRepository _iceConnectorRepository;

        /// <summary>
        /// IceDeleteProjDBAsync() - Test method to validate IceDeleteProjDBAsync()
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task IceDeleteProjDBAsync()
        {
            try
            {
                var token = new CancellationToken();
                var cancellationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(token);
                var httpClient = new HttpClient();
                var progress = new Progress<ProgressReport>();
                progress.ProgressChanged += ReportProgress;
                var ice = new IceConnector(iceApiHost: "lvsvtaucmw01.consiliotest.com", port: 4080, httpClient);
                var deleteProjectResponse = ice.DeleteProjectDatabase(10602, progress, cancellationTokenSource.Token);
                IceLogger.LogInformation($"{deleteProjectResponse.Id}{deleteProjectResponse.Status}");
            }
            catch (Exception e)
            {
                IceLogger.LogError("Failed due to exception: " + e.Message);
                Assert.Fail();
            }
        }

        private void ReportProgress(object? sender, ProgressReport e)
        {
            switch (e.Message)
            {
                case null:
                case "":
                    IceLogger.LogInformation($"{DateTime.UtcNow:HH:mm:ss.ff} {e.Progress}");
                    break;
                default:
                    IceLogger.LogInformation($"{DateTime.UtcNow:HH:mm:ss.ff} {e.Progress} - {e.Message}");
                    break;
            }

        }
    }
}
