/**
 * Unpublished Work. Copyrights� 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using AventStack.ExtentReports;
using IceTestAutomation.Pages.ICEApiPages;
using IceTestAutomation.Utilities;
using Newtonsoft.Json;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using RestSharp;
using System;
using System.Net;
using static IceTestAutomation.IceApiClasses.ProjectApiClass;

namespace IceTestAutomation
{

    /// <summary>
    /// ProjectApiTests - Test Suite for testing both happy and unhappy test cases for Project Endpoints.
    /// </summary>
    [TestFixture]
    public class ProjectApiTests : BaseTest
    {
        private IRestResponse? projectAPIResponse;
        protected static RestClient? clientApi;

        /// <summary>
        /// setUp() - Method to Initialize Test Suite
        /// </summary>
        [OneTimeSetUp]
        public void setUp()
        {
        }

        /// <summary>
        /// This test will get all project details from ICE application
        /// </summary>
        [Test]
        public void TC01_GetAllProjectTests()
        {
            try
            {
                IceProjectApiPages projectIceApi = new IceProjectApiPages(clientApi);
                projectAPIResponse = projectIceApi.GetAllProjectDetails();
                Assert.AreEqual(HttpStatusCode.OK, projectAPIResponse.StatusCode);
                IceLogger.LogInformation("Project Details are as follows: " + projectAPIResponse.Content);
            }
            catch (Exception ex)
            {
                IceLogger.LogError("Test Failed due to " +ex.ToString());
                Assert.Fail(ex.ToString());
            }

        }

        /// <summary>
        /// This test will get the specific or particular project details.
        /// </summary>
        [Test]
        public void TC02_GetSpecificProjectTests()
        {
            try
            {
                IceProjectApiPages projectIceApi = new IceProjectApiPages(clientApi);
                int lastUsedProjectId = projectIceApi.GetlastUsedProjectId();
                projectAPIResponse = projectIceApi.GetSpecificProjectDetails(lastUsedProjectId);
                Assert.AreEqual(HttpStatusCode.OK, projectAPIResponse.StatusCode);
                IceLogger.LogInformation("Project Details are as follows: " + projectAPIResponse.Content);
            }
            catch (Exception ex)
            {
                IceLogger.LogError("Test Failed due to " +ex.ToString());
                Assert.Fail(ex.ToString());
            }
        }

        /// <summary>
        /// This test will test the HTTP 500 Internal server error validation when project instance
        /// doesn't exist.
        /// </summary>
        [Test]
        public void TC03_GetSpecificInvalidProjectTests()
        {
            try
            {
                IceProjectApiPages projectIceApi = new IceProjectApiPages(clientApi);
                int lastUsedProjectId = projectIceApi.GetlastUsedProjectId();
                lastUsedProjectId = lastUsedProjectId + 1;
                projectAPIResponse = projectIceApi.GetSpecificProjectDetails(lastUsedProjectId);
                Assert.AreEqual(HttpStatusCode.InternalServerError, projectAPIResponse.StatusCode);
                test.Log(Status.Warning, "Invalid Project details requested " + projectAPIResponse.Content);
            }
            catch (Exception ex)
            {
                IceLogger.LogError("Test Failed due to " +ex.ToString());
                Assert.Fail(ex.ToString());
            }
        }

        /// <summary>
        /// This test will create a new project with standard workflow
        /// </summary>
        [Test]
        public void TC04_CreateProjectStandardWorflowTests()
        {
            try
            {
                IceProjectApiPages projectIceApi = new IceProjectApiPages(clientApi);
                projectAPIResponse = projectIceApi.CreateIceProjectWithStandardWorkflow();
                int lastUsedProjectId = projectIceApi.GetlastUsedProjectId();
                GetProjectApiClass deserializedOutput = JsonConvert.DeserializeObject<GetProjectApiClass>(projectAPIResponse.Content.ToString());
                Assert.AreEqual(HttpStatusCode.OK, projectAPIResponse.StatusCode);
                Assert.AreEqual(lastUsedProjectId, deserializedOutput.id);
                IceLogger.LogInformation("Created Project, details are as follows: " + projectAPIResponse.Content);
            }
            catch (Exception ex)
            {
                IceLogger.LogError("Test Failed due to " +ex.ToString());
                Assert.Fail(ex.ToString());
            }
        }

        /// <summary>
        /// This test will delete a specific project
        /// </summary>
        [Test]
        public void TC05_DeleteProjectTests()
        {
            try
            {
                IceProjectApiPages projectIceApi = new IceProjectApiPages(clientApi);
                projectAPIResponse = projectIceApi.DeleteProject(145);
                GetProjectApiClass deserializedOutput = JsonConvert.DeserializeObject<GetProjectApiClass>(projectAPIResponse.Content.ToString());
                Assert.AreEqual(HttpStatusCode.OK, projectAPIResponse.StatusCode);
                IceLogger.LogInformation("Deleted Project, details are as follows: " + projectAPIResponse.Content);
            }
            catch (Exception ex)
            {
                IceLogger.LogError("Test Failed due to " +ex.ToString());
                Assert.Fail(ex.ToString());
            }
        }

        /// <summary>
        /// This method will destroy the ICE session after all the tests run in this test suite.
        /// </summary>
        [OneTimeTearDown]
        public void tearDown()
        {
            clientApi = null;
        }
    }
}