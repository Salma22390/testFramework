﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using AventStack.ExtentReports;
using Ice.Sdk;
using Ice.Sdk.Models;
using Ice.Sdk.OpenApi;
using IceTestAutomation.Utilities;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace IceTestAutomation.Tests.IceApiTests
{
    /// <summary>
    /// Test Suite for ICE-9777 SQL Backup API tests
    /// </summary>
    [TestFixture]
    public class IceSqlBackUpTests : BaseTest
    {
        private readonly IIceConnectorRepository _iceConnectorRepository;

        /// <summary>
        /// IceCreateBackupAsync() - Method to validate create ICE backup
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task IceCreateBackupAsync()
        {
            try
            {
               
                var token = new CancellationToken();
                var cancellationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(token);
                var httpClient = new HttpClient();
                var ice = new IceConnector(iceApiHost: "lvsvtaucmw01.consiliotest.com", port: 4080, httpClient);
                var progress = new Progress<BackgroundJobProgress>();
                progress.ProgressChanged += ReportProgress2;
                var backUpSettings = new BackupRestoreProjectSettings { ProjectId = 10738, CompressionLevel = CompressionLevel.None, Options = BackupRestoreOptions.Natives, Path = @"\\lvsdevnas10.consilioTest.com\ice_datasets\Transfer\Export\Backups" };
                var backupJob = ice.CreateBackupJobAsync(backUpSettings, progress, cancellationTokenSource.Token);
                
                var monitorJob =  ice.MonitorJobStatusAsync(backupJob.Result, progress, cancellationTokenSource.Token);
                //progress.ProgressChanged -= ReportProgress2;
                IceLogger.LogInformation($"{monitorJob.Status}");
            }
            catch (Exception e)
            {
                IceLogger.LogError("Failed due to exception: " + e.Message);
                Assert.Fail();
            }
        }

        private void ReportProgress(object? sender, ProgressReport e)
        {
            switch (e.Message)
            {
                case null:
                case "":
                    IceLogger.LogInformation( "Status of Restore Job " + $"{DateTime.UtcNow:HH:mm:ss.ff} {e.Message}/{e.Progress}");
                    break;
                default:
                    IceLogger.LogInformation( "Status of restore job " + $"{DateTime.UtcNow:HH:mm:ss.ff} {e.Message}/{e.Progress} - {e.Message}");
                    break;
            }

        }

        private void ReportProgress2(object? sender, BackgroundJobProgress e)
        {
            switch (e.Message)
            {
                case null:
                case "":
                    IceLogger.LogInformation("Restore Job Status " +  $"{DateTime.UtcNow:HH:mm:ss.ff} {e.Id}/{e.Status}");
                    break;
                default:
                    IceLogger.LogInformation("Restore Job Status " +  $"{DateTime.UtcNow:HH:mm:ss.ff} {e.Id}/{e.Status} - {e.Message}");
                    break;
            }

        }
    }
}
