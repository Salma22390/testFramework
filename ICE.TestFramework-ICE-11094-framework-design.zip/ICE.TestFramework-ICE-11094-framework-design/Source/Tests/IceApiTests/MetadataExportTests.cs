﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using AventStack.ExtentReports;
using Ice.Sdk;
using IceTestAutomation.Utilities;
using NUnit.Framework;
using NUnit.Framework.Interfaces;

namespace IceTestAutomation.Tests.IceApiTests
{
    [TestFixture]
    public class MetadataExportTests : BaseTest
    {
        private readonly IIceConnectorRepository _iceConnectorRepository;
        /// <summary>
        /// IceMetadataReader() - Test method to validate ICE Metadata Reader.
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task IceMetadataReader()
        {
            var token = new CancellationToken();
            var cancellationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(token);
            var httpClient = new HttpClient();
            var ice = new IceConnector(iceApiHost: "lvsvtaucmw01.consiliotest.com", port: 4080, httpClient);

        }
    }
}
