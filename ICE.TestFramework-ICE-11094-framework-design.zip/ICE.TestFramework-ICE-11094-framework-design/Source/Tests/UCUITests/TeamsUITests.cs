﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using AventStack.ExtentReports;
using IceTestAutomation.AbstractClasses;
using IceTestAutomation.Pages.UCUIPages;
using IceTestAutomation.Utilities;
using Newtonsoft.Json;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceTestAutomation.Tests.UCUITests
{
    [TestFixture]
    public class TeamsUITests : BaseTest
    {

        //private IWebDriver driver;
        public IDictionary<string, object> vars { get; private set; }
        private IJavaScriptExecutor js;
        ReadAppSettings appSettings = new ReadAppSettings();
        static string teamsJobSettingsPath = System.IO.Directory.GetParent("../../../").FullName + "/Settings/msteamsjobsettings.json";
        static string jsonString = File.ReadAllText(teamsJobSettingsPath);
        dynamic teamsJobSettings = JsonConvert.DeserializeObject(jsonString);
        protected static IWebDriver driver;
        [OneTimeSetUp]
        public void SetUp()
        {
            UCUIDriver ucDriver = new UCUIDriver();
            driver = ucDriver.initBrowser();
            driver.Navigate().GoToUrl("http://SD_EU_ICE_AUTO:pUL9Yasy04X@lhr@ucstaging.consiliotest.com//");
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            //driver = new ChromeDriver();
            //driver.Manage().Window.FullScreen();
        }

        [OneTimeTearDown]
        protected void TearDown()
        {
            driver.Close();
        }

        [Test]
        public void createNewTeamsProject()
        {
            UCUIHomePage homePage = new UCUIHomePage(driver);
            UCUIMsTeamsJobPage chimeJobPage = new UCUIMsTeamsJobPage(driver);
            UCUIJobCompletion uCUIJobCompletion = new UCUIJobCompletion(driver);

            try
            {
                
                Assert.IsTrue(homePage.CreateNewProject("AutomationDemo"));
                IceLogger.LogInformation("AutomationDemo project created successfully");
                Assert.IsTrue(chimeJobPage.CreateNewTeamsJob("AutomationDemo"));
                IceLogger.LogInformation("AutomatedMsTeamsJob job created successfully");
                Assert.IsTrue(chimeJobPage.SaveTeamsJobSettings());
                Assert.IsTrue(chimeJobPage.RunTeamsJob());
                IceLogger.LogInformation("AutomatedTeamsJob job Running");
                Assert.IsTrue(uCUIJobCompletion.GetNewJobCompletionStatus((string)teamsJobSettings.MsTeamsJobName));
                IceLogger.LogInformation("AutomatedTeamsJob job completed successfully");
                
            }
            catch (Exception ex)
            { 
                IceLogger.LogError(ex.StackTrace);
                Assert.Fail(ex.Message); 
            }
        }
    }
}
