﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using AventStack.ExtentReports;
using IceTestAutomation.AbstractClasses;
using IceTestAutomation.Pages.UCUIPages;
using IceTestAutomation.Utilities;
using Newtonsoft.Json;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.IO;

namespace IceTestAutomation.Tests.UCUITests
{

    /// <summary>
    /// ChimeUITests - Test suite to test Chime Conversion related tests
    /// </summary>
    [TestFixture]
    public class ChimeUITests : BaseTest
    {
        public IDictionary<string, object> vars { get; private set; }
        private IJavaScriptExecutor js;
        ReadAppSettings appSettings = new ReadAppSettings();
        static string chimeJobSettingsPath = System.IO.Directory.GetParent("../../../").FullName + "/Settings/chimejobsettings.json";
        static string jsonString = File.ReadAllText(chimeJobSettingsPath);
        dynamic chimeJobSettings = JsonConvert.DeserializeObject(jsonString);
        protected static IWebDriver driver;

        /// <summary>
        /// One Time setup method to initialize the UC UI.
        /// </summary>
        [OneTimeSetUp]
        public void SetUp()
        {
            UCUIDriver ucDriver = new UCUIDriver();
            driver = ucDriver.initBrowser();
            driver.Navigate().GoToUrl("http://SD_EU_ICE_AUTO:pUL9Yasy04X@lhr@ucstaging.consiliotest.com//");
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
        }
        /// <summary>
        /// TerDown() method to close the browser session.
        /// </summary>
        [OneTimeTearDown]
        protected void TearDown()
        {
            driver.Close();
        }

        /// <summary>
        /// createNewProject() - Test to create a new project and a new chime Job.
        /// </summary>
        [Test]
        public void createNewProject()
        {
            UCUIHomePage homePage = new UCUIHomePage(driver);
            UCUIChimeJobPage chimeJobPage = new UCUIChimeJobPage(driver);
            UCUIJobCompletion uCUIJobCompletion = new UCUIJobCompletion(driver);
            try
            {
                
                Assert.IsTrue(homePage.CreateNewProject("AutomationDemo"));
                IceLogger.LogInformation("AutomationDemo project created successfully");
                Assert.IsTrue(chimeJobPage.CreateNewChimeJob("AutomationDemo"));
                IceLogger.LogInformation("AutomatedChimeJob job created successfully");
                Assert.IsTrue(chimeJobPage.SaveChimeJobSettings());
                Assert.IsTrue(chimeJobPage.RunChimeJob());
                IceLogger.LogInformation("AutomatedChimeJob job Running");
                Assert.IsTrue(uCUIJobCompletion.GetNewJobCompletionStatus((string)chimeJobSettings.ChimeJobName));
                IceLogger.LogInformation("AutomatedChimeJob job completed successfully");
                
            }
            catch (Exception ex)
            { 
                IceLogger.LogError(ex.StackTrace);
                Assert.Fail(ex.Message); 
            }
        }
    }
}
