﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using IceTestAutomation.Pages.ICEDBPages;
using IceTestAutomation.Utilities;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceTestAutomation.Tests.iceDbTests
{

    /// <summary>
    /// ExecuteDbTests - Test suite to execute DataBase tests
    /// </summary>
    [TestFixture]
    public class ExecuteDbTests : BaseTest
    {

        /// <summary>
        /// This test will execute script on Ice database
        /// </summary>
        [Test]
        public void ExecuteScriptOnIceDb()
        {
            string sqlConnectionString = @"Data Source=LVSVTDUCSQL01;Initial Catalog=ICE000275;User ID=SD_EU_ICE;Password=puppy-chats-sally-K9";
            IceDbPage iceDbConnection = new IceDbPage(sqlConnectionString);
            try
            {
                string script = File.ReadAllText(System.IO.Directory.GetParent("../../../").FullName + "/SqlScripts/ICEQAReport.sql");
                iceDbConnection.executeSqlQueryWithOutput(script);
            }
            catch (Exception ex)
            {
                IceLogger.LogError("Failed due to " + ex.StackTrace);
                Assert.Fail(ex.Message);
            }
        }
    }
}
