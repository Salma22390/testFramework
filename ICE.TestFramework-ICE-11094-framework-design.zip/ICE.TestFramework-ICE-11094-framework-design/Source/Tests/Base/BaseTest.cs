﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using AventStack.ExtentReports;
using IceTestAutomation.Utilities;
using NUnit.Framework;
using NUnit.Framework.Interfaces;

namespace IceTestAutomation
{
    /// <summary>
    /// BaseTest - Class to Initialize the Extent Report (HTML reporting), Serilog instance (.NET logging),
    /// Test Context and Application Settings of the test automation framework.
    /// </summary>
    public abstract class BaseTest
    {
        protected static AventStack.ExtentReports.ExtentTest test;
        protected static string? IceUrl;
        static ReadAppSettings? appSettings;

        [OneTimeSetUp]
        public void Setup()
        {
            appSettings = new ReadAppSettings();
            IceUrl = appSettings.GetAppSettings().IceAPIUrl;
        }

        [SetUp]
        public void beforeTestMethod()
        {
            string testName = TestContext.CurrentContext.Test.Name;
            test=IceLogger.StartTest(testName);
        }
        
        [TearDown]
        public void afterTestMethod()
        {
            string testName = TestContext.CurrentContext.Test.Name;
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            switch (status)
            {
                case TestStatus.Passed:
                    test.Log(Status.Pass, "Test case: " + testName + " Passed");
                    break;
                case TestStatus.Failed:
                    test.Log(Status.Fail, "Test case: " + testName + " failed");
                     break;
                default:
                    //test.Log(Status.Info, "Something went wrong!");
                    break;

            }
        }
    }
}