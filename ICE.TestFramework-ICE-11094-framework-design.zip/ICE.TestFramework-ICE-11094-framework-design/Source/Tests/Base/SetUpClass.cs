/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using IceTestAutomation.Utilities;
using NUnit.Framework;

namespace IceTestAutomation
{
    
    /// <summary>
    /// BaseTest - Class to Initialize the Extent Report (HTML reporting), Serilog instance (.NET logging),
    /// Test Context and Application Settings of the test automation framework.
    /// </summary>
    [SetUpFixture]
    class SetUpClass
    {
        [OneTimeSetUp]
        protected void Setup()
        {
            IceLogger.Initialize();
        }

        [OneTimeTearDown]
        protected void TearDown()
        {
            IceLogger.EndTest();
        }
    }
}