﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using IceTestAutomation.AbstractClasses;
using IceTestAutomation.Interfaces;
using IceTestAutomation.Utilities;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static IceTestAutomation.IceApiClasses.ExhibitApiClass;
using static IceTestAutomation.IceApiClasses.ProjectApiClass;

namespace IceTestAutomation.Pages.ICEApiPages
{

    /// <summary>
    /// IceExhibitApiPages - Class to define methods for Exhibit endpoints
    /// </summary>
    class IceExhibitApiPages
    {
        private IRestClient iceRestClient;
        private IRestRequest iceRestRequest;
        private IRestResponse iceRestResponse;
        ReadAppSettings appSettings = new ReadAppSettings();
        IceAPIClient iceApiInterface = new IceAPIAbstraction();

        public IceExhibitApiPages(RestClient restclient)
        {
            iceRestClient = restclient;
        }

        /// <summary>
        /// GetExhibitDetails() - Method to get all added exhibit details
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public IRestResponse GetExhibitDetails(int projectID)
        {
            iceRestRequest = iceApiInterface.createGetRequest(appSettings.GetAppSettings().ProjectsURI.GetPostURI + "/" + projectID.ToString() + "/exhibits");
            iceRestResponse = iceApiInterface.GetResponse(iceRestClient, iceRestRequest);
            return iceRestResponse;
        }

        /// <summary>
        /// AddExhibits() - Method to add a new exhibit to the project.
        /// </summary>
        /// <param name="projectID"></param>
        /// <param name="custodianId"></param>
        /// <param name="custodianName"></param>
        /// <returns></returns>
        public IRestResponse AddExhibits(int projectID, int custodianId, string custodianName)
        {
            iceRestResponse = GetExhibitDetails(projectID);
            GetExhibitApiClass deserializedOutput = JsonConvert.DeserializeObject<GetExhibitApiClass>(iceRestResponse.Content.ToString());
            int exhibitId = 0;
            if (deserializedOutput != null)
            {
                exhibitId = deserializedOutput.Id+1;
            }
            else
            {
                exhibitId++;
            }
            var setProjectParameters = new GetExhibitApiClass
            {
                Id = exhibitId,
                Name = "AutomationTest-" + exhibitId,
                Description = "Exhibit Added by AutomationTest - " + appSettings.GetAppSettings().DatasetUncPath,
                UncPath = appSettings.GetAppSettings().DatasetUncPath,
                CustodianId = custodianId,
                CustodianName = custodianName,
                CreatedFrom = appSettings.GetAppSettings().HostName,
                CreatedBy = "Automation Test"
            };
            string jsonBody = JsonConvert.SerializeObject(setProjectParameters);
            iceRestRequest = iceApiInterface.createPostRequest(appSettings.GetAppSettings().ProjectsURI.GetPostURI + "/" + projectID.ToString() + "/exhibits", jsonBody);
            iceRestResponse = iceApiInterface.GetResponse(iceRestClient, iceRestRequest);
            return iceRestResponse;
        }

        /// <summary>
        /// CrackExhibits - Crack or process newly added exhibit
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="exhibitId"></param>
        /// <returns></returns>
        public bool CrackExhibits(int projectId, int exhibitId)
        {
            string jsonBody = "";
            iceRestRequest = iceApiInterface.createPostRequest(appSettings.GetAppSettings().ProjectsURI.GetPostURI + "/" + projectId.ToString() + "/exhibits/" + exhibitId.ToString() + "/process", jsonBody);
            iceRestResponse = iceApiInterface.GetResponse(iceRestClient, iceRestRequest);
            GetExhibitApiClass deserializedOutput = JsonConvert.DeserializeObject<GetExhibitApiClass>(iceRestResponse.Content.ToString());
            if (deserializedOutput.Status == "Cracking")
                return true;
            else
                return false;

        }

        /// <summary>
        /// GetExhibitStatus() - Method to get the processing status of exhibit cracked.
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="exhibitId"></param>
        /// <returns></returns>
        public bool GetExhibitStatus (int projectId, int exhibitId)
        {
            iceRestRequest = iceApiInterface.createGetRequest(appSettings.GetAppSettings().ProjectsURI.GetPostURI + "/" + projectId.ToString() + "/exhibits/" + exhibitId.ToString());
            iceRestResponse = iceApiInterface.GetResponse(iceRestClient, iceRestRequest);
            GetExhibitApiClass deserializedOutput = JsonConvert.DeserializeObject<GetExhibitApiClass>(iceRestResponse.Content.ToString());
            while (deserializedOutput.Status != "Cracked")
            {
                System.Threading.Thread.Sleep(1000);
                iceRestResponse = iceApiInterface.GetResponse(iceRestClient, iceRestRequest);
                deserializedOutput = JsonConvert.DeserializeObject<GetExhibitApiClass>(iceRestResponse.Content.ToString());
            }
            if (deserializedOutput.Status == "Cracked")
                return true;
            else
                return false;
        }
    }
}
