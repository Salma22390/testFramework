﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using IceTestAutomation.AbstractClasses;
using IceTestAutomation.Interfaces;
using IceTestAutomation.Utilities;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using static IceTestAutomation.IceApiClasses.ProjectApiClass;

namespace IceTestAutomation.Pages.ICEApiPages
{

    /// <summary>
    /// IceProjectApiPages - Class that defines the methods for Project endpoint.
    /// </summary>
    class IceProjectApiPages
    {
        private IRestClient iceRestClient;
        private IRestRequest iceRestRequest;
        private IRestResponse iceRestResponse;
        ReadAppSettings appSettings = new ReadAppSettings();
        IceAPIClient iceApiInterface = new IceAPIAbstraction();

        public IceProjectApiPages(RestClient restclient)
        {
            iceRestClient = restclient;
        }

        /// <summary>
        /// GetAllProjectDetails() - Method to get all the project details of connected server instance.
        /// </summary>
        /// <returns></returns>
        public IRestResponse GetAllProjectDetails()
        {
            iceRestRequest = iceApiInterface.createGetRequest(appSettings.GetAppSettings().ProjectsURI.GetPostURI);
            iceRestResponse = iceApiInterface.GetResponse(iceRestClient, iceRestRequest);
            return iceRestResponse;
        }

        /// <summary>
        /// GetSpecificProjectDetails() - Method to get specific or particular project details.
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public IRestResponse GetSpecificProjectDetails(int projectID)
        {
            iceRestRequest = iceApiInterface.createGetRequest(appSettings.GetAppSettings().ProjectsURI.GetPostURI + "/" + projectID.ToString());
            iceRestResponse = iceApiInterface.GetResponse(iceRestClient, iceRestRequest);
            return iceRestResponse;
        }

        /// <summary>
        /// GetlastUsedProjectId() - Method that will get last created project ID
        /// </summary>
        /// <returns></returns>
        public int GetlastUsedProjectId()
        {
            iceRestResponse = GetAllProjectDetails();
            List<int> ids = new List<int>();
            List<GetProjectApiClass>? getProjectApiObjects = JsonConvert.DeserializeObject<List<GetProjectApiClass>?>(iceRestResponse.Content.ToString());
            foreach (GetProjectApiClass obj in getProjectApiObjects)
                ids.Add(obj.id);
            Console.WriteLine("Last used Project ID: " + ids.Max());
            return ids.Max();
        }

        /// <summary>
        /// CreateIceProjectWithStandardWorkflow() - Method to create ICE project with standard workflow.
        /// </summary>
        /// <returns></returns>
        public IRestResponse CreateIceProjectWithStandardWorkflow()
        {
            int lastUsedProjectId = GetlastUsedProjectId();
            Guid projectUuid = new Guid();
            string iceProjectUuid = projectUuid.ToString();
            lastUsedProjectId = lastUsedProjectId + 1;
            var setProjectParameters = new GetProjectApiClass
            {
                id = lastUsedProjectId,
                uuid = iceProjectUuid,
                name = "AutomationTest" + lastUsedProjectId,
                databaseName = "ICE0000" + lastUsedProjectId,
                description = "Created by Automation",
                createdFrom = appSettings.GetAppSettings().HostName,
                createdBy = "AutomationTestAdmin",
                number = "",
                client = "",
                workflow = "Standard",
                jobCount = 0,
                lastOpenedBy = "",
                lastUpdatedBy = ""
            };
            string jsonBody = JsonConvert.SerializeObject(setProjectParameters);
            iceRestRequest = iceApiInterface.createPostRequest(appSettings.GetAppSettings().ProjectsURI.GetPostURI, jsonBody);
            iceRestResponse = iceApiInterface.GetResponse(iceRestClient, iceRestRequest);
            return iceRestResponse;
        }

        /// <summary>
        /// DeleteProject - Method to delete a project instance.
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public IRestResponse DeleteProject (int projectID)
        {
            iceRestRequest = iceApiInterface.createDeleteRequest(appSettings.GetAppSettings().ProjectsURI.GetPostURI + "/" + projectID.ToString());
            iceRestResponse = iceApiInterface.GetResponse(iceRestClient, iceRestRequest);
            return iceRestResponse;
        }
    }
}
