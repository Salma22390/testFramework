﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using IceTestAutomation.AbstractClasses;
using IceTestAutomation.Interfaces;
using IceTestAutomation.Utilities;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static IceTestAutomation.IceApiClasses.CustodianApiClass;

namespace IceTestAutomation.Pages.ICEApiPages
{

    /// <summary>
    /// IceCustodianApiPages - Class that defines methods of API endpoints.
    /// </summary>
    class IceCustodianApiPages
    {
        private IRestClient iceRestClient;
        private IRestRequest iceRestRequest;
        private IRestResponse iceRestResponse;
        ReadAppSettings appSettings = new ReadAppSettings();
        IceAPIClient iceApiInterface = new IceAPIAbstraction();

        public IceCustodianApiPages (RestClient restclient)
        {
            iceRestClient = restclient;
        }

        /// <summary>
        /// GetCustodianDetails - Method to get custodian details added.
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public IRestResponse GetCustodianDetails(int projectID)
        {
            iceRestRequest = iceApiInterface.createGetRequest(appSettings.GetAppSettings().ProjectsURI.GetPostURI + "/" + projectID.ToString() + "/custodians");
            iceRestResponse = iceApiInterface.GetResponse(iceRestClient, iceRestRequest);
            return iceRestResponse;
        }

        /// <summary>
        /// AddCustodians() - Method to add Custodian to new project.
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public IRestResponse AddCustodians(int projectID)
        {
            Random randomId = new Random();
            int custodianId;
            custodianId = randomId.Next();
            var setProjectParameters = new GetCustodianApiClass
            {
                id = custodianId,
                name = "AutomationTest-" + custodianId
            };
            string jsonBody = JsonConvert.SerializeObject(setProjectParameters);
            iceRestRequest = iceApiInterface.createPostRequest(appSettings.GetAppSettings().ProjectsURI.GetPostURI + "/" + projectID.ToString() + "/custodians", jsonBody);
            iceRestResponse = iceApiInterface.GetResponse(iceRestClient,iceRestRequest);
            return iceRestResponse;
        }

        /// <summary>
        /// DeleteCustodians() - Method to delete custodian(s) for a particular project.
        /// </summary>
        /// <param name="projectID"></param>
        /// <param name="custodianId"></param>
        /// <returns></returns>
        public IRestResponse DeleteCustodians(int projectID, int custodianId)
        {
            iceRestRequest = iceApiInterface.createDeleteRequest(appSettings.GetAppSettings().ProjectsURI.GetPostURI + "/" + projectID.ToString() + "/custodians/" + custodianId.ToString());
            iceRestResponse = iceApiInterface.GetResponse(iceRestClient, iceRestRequest);
            return iceRestResponse;
        }
    }
}
