﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using IceTestAutomation.Utilities;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceTestAutomation.Pages.UCUIPages
{
    /// <summary>
    /// UCUIHomePage - class interacts with various web elements exposed for creating new project. 
    /// </summary>
    class UCUIHomePage
    {
        private IWebDriver driver;
        private WebDriverWait wait;
        public UCUIHomePage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.Id, Using = "new-project-btn")]
        private IWebElement NewProjectButton;

        [FindsBy(How = How.Id, Using = "newProjectName")]
        private IWebElement NewProjectNameField;

        [FindsBy(How = How.Id, Using = "newProjectClientName")]
        private IWebElement NewProjectClientNameField;

        [FindsBy(How = How.Id, Using = "newProjectHCode")]
        private IWebElement NewProjectHCodeField;

        [FindsBy(How = How.Id, Using = "descriptionTextarea")]
        private IWebElement DescriptionTextAreaField;

        [FindsBy(How = How.Id, Using = "dialog-confirm")]
        private IWebElement DialogConfirmButton;

        [FindsBy(How = How.CssSelector, Using = "label > input")]
        private IWebElement ProjectSearchField;

        /// <summary>
        /// CreateNewProject - Method to create new project in UC UI
        /// </summary>
        /// <param name="projectName"></param>
        /// <returns></returns>
        public bool CreateNewProject(string projectName)
        {
            try
            {
                NewProjectButton.Click();
                NewProjectNameField.Click();
                NewProjectNameField.SendKeys(projectName);
                NewProjectClientNameField.Click();
                NewProjectClientNameField.SendKeys("AutomationClient");
                NewProjectHCodeField.Click();
                NewProjectHCodeField.SendKeys("Automation12345");
                DescriptionTextAreaField.Click();
                DescriptionTextAreaField.SendKeys("This project is created by Automation Script");
                DialogConfirmButton.Click();
                /*var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(120));
                wait.Until(driver => IsAlertShown(driver));
                IAlert alert = driver.SwitchTo().Alert();
                Assert.That(alert.Text, Is.EqualTo("Project \"" + projectName + "\" has been created."));
                alert.Accept();
                Log.Information(projectName + " Created Successfully");
                ProjectSearchField.Click();
                ProjectSearchField.SendKeys(projectName);
                driver.FindElement(By.LinkText(projectName)).Click();*/
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(120));
                wait.Until(driver => driver.FindElement(By.XPath("//span[@id='heading-label'][contains(text(),'" + projectName + "')]")));
                IWebElement projectPage = driver.FindElement(By.XPath("//span[@id='heading-label'][contains(text(),'" + projectName + "')]"));
                Assert.IsNotNull(projectPage);
                Console.WriteLine("Now, In " + projectName + " UI Page");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(projectName + " failed to create due to exception: " + ex.Message);
                return false;
            }
            
        }

        /// <summary>
        /// Deprecated method -- Not required as of now.
        /// </summary>
        /// <param name="driver"></param>
        /// <returns></returns>
        bool IsAlertShown(IWebDriver driver)
        {
            try
            {
                driver.SwitchTo().Alert();
            }
            catch (NoAlertPresentException e)
            {
                Console.WriteLine("No Alert for project creation: " + e.Message + " waiting for " + TimeSpan.FromSeconds(120));
                return false;
            }
            return true;
        }


    }
}
