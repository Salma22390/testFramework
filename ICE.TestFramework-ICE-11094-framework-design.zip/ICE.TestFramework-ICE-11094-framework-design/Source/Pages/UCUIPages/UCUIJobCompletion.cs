﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using Serilog;
using System;

namespace IceTestAutomation.Pages.UCUIPages
{
    /// <summary>
    /// UCUIJobCompletion - Class that defines methods to check the status of UC Job.
    /// </summary>
    class UCUIJobCompletion
    {
        private IWebDriver driver;
        private WebDriverWait wait;
        private IJavaScriptExecutor js;
        public UCUIJobCompletion(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            PageFactory.InitElements(driver, this);
        }

        /// <summary>
        /// GetNewJonCompletionStatus - Method to the completion status of the new job created in UC UI.
        /// </summary>
        /// <param name="jobName"></param>
        /// <returns></returns>
        public bool GetNewJobCompletionStatus(String jobName)
        {
            try
            {
                IWebElement element = driver.FindElement(By.XPath("//td[text()='" + jobName + "']"));
                if (element != null)
                {
                    Log.Information(jobName + " found");
                }
                var wait = new WebDriverWait(driver, timeout: TimeSpan.FromMinutes(20))
                {
                    PollingInterval = TimeSpan.FromSeconds(25),
                };
                wait.IgnoreExceptionTypes(typeof(NoSuchElementException));

                /*
                do
                {
                    driver.Navigate().Refresh();

                } while (wait.Until<IWebElement>(driver => driver.FindElement(By.XPath("//a[@data-job-name='" + jobName + "' and text()='Complete']"))!=null);
                /*
                wait = new WebDriverWait(driver, timeout: TimeSpan.FromMinutes(20))
                {
                    PollingInterval = TimeSpan.FromSeconds(25),
                };
                wait.IgnoreExceptionTypes(typeof(NoSuchElementException));

                var foo = wait.Until <IWebElement>(driver => driver.FindElement(By.XPath("//a[@data-job-name='" + jobName + "' and text()='Complete']")));
                */
                var foo = wait.Until(driver => driver.FindElement(By.XPath("//a[@data-job-name='" + jobName + "' and text()='Complete']")));
                Console.WriteLine("Job Completed successfully:" + foo.Text);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to complete the job due to exception: " + ex.ToString());
                return false;
            }
            

        }

    }
}
