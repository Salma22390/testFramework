﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using Newtonsoft.Json;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceTestAutomation.Pages.UCUIPages
{

    /// <summary>
    /// UCUIMsTeamsJobPage - Class that defines the methods to create a new MS Teams Job in UC UI.
    /// </summary>
    class UCUIMsTeamsJobPage
    {
        private IWebDriver driver;
        private WebDriverWait wait;
        private IJavaScriptExecutor js;
        static string teamsJobSettingsPath = System.IO.Directory.GetParent("../../../").FullName + "/Settings/msteamsjobsettings.json";
        static string jsonString = File.ReadAllText(teamsJobSettingsPath);
        dynamic teamsJobSettings = JsonConvert.DeserializeObject(jsonString);
        public UCUIMsTeamsJobPage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.Id, Using = "new-job-btn")]
        private IWebElement NewJobButton;

        [FindsBy(How = How.Id, Using = "newJobName")]
        private IWebElement NewJobNameField;

        [FindsBy(How = How.Id, Using = "conversionTypeFocusElement")]
        private IWebElement ConversationDropDown;

        [FindsBy(How = How.XPath, Using = "//li[contains(text(),'Microsoft Teams PST')]")]
        private IWebElement TeamsConversationTypeSelect;

        [FindsBy(How = How.Id, Using = "newJobSourceFilePath")]
        private IWebElement NewJobSourceFilePathField;

        [FindsBy(How = How.Id, Using = "newJobCustodianName")]
        private IWebElement NewJobCustodianNameField;

        [FindsBy(How = How.Id, Using = "descriptionTextarea")]
        private IWebElement DescriptionTextAreaField;

        [FindsBy(How = How.Id, Using = "dialog-confirm")]
        private IWebElement DialogConfirmButton;

        [FindsBy(How = How.CssSelector, Using = "#dialog-cancel")]
        private IWebElement JobCancelButton;

        // Settings Part Element Locators
        [FindsBy(How = How.CssSelector, Using = "#txtTeamsOutputFolder")]
        private IWebElement TeamsOutputPath;

        [FindsBy(How =How.XPath, Using = "//div[contains(text(),'(UTC) Coordinated Universal Time')]")]
        private IWebElement TeamsTimeZoneDropDown;

        [FindsBy(How = How.XPath, Using = "//body/div[17]/ul[1]/li")]
        private IList<IWebElement> TeamsTimeZoneDropDownList;

        [FindsBy(How = How.CssSelector, Using = "#teamsCustodianAutoCkbx")]
        private IWebElement TeamsCustodianAutoCheck;

        [FindsBy(How = How.CssSelector, Using = "#teamsCustodianNameTxt")]
        private IWebElement TeamsCustodianName;

        [FindsBy(How = How.CssSelector, Using = "#teamsOwnerDisplayNameTxt")]
        private IWebElement TeamsOwnerName;

        [FindsBy(How = How.CssSelector, Using = "#txtTeamsControlNumberPrefix")]
        private IWebElement TeamsControlNumberPrefix;

        [FindsBy(How = How.XPath, Using = "//body/div[2]/main[1]/div[1]/div[6]/div[3]/div[1]/div[2]/div[2]/input[1]")]
        private IWebElement TeamsPrependZeros;

        [FindsBy(How = How.XPath, Using = "//body/div[2]/main[1]/div[1]/div[6]/div[3]/div[1]/div[2]/div[3]/input[1]")]
        private IWebElement TeamsStartingNumber;

        [FindsBy(How = How.XPath, Using = "//body/div[2]/main[1]/div[1]/div[6]/div[2]/div[1]/div[1]/div[1]/button[2]/span[3]")]
        private IWebElement UnitizationExportTab;

        [FindsBy(How = How.CssSelector, Using = "#teamsOptSplitPerDay")]
        private IWebElement TeamsSplitPerDayOption;

        [FindsBy(How = How.CssSelector, Using = "#teamsOptSingleItem")]
        private IWebElement TeamsSingleItemOption;

        [FindsBy(How = How.CssSelector, Using = "#teamsOptGapAnalysis")]
        private IWebElement TeamsConversationGapOption;

        [FindsBy(How = How.XPath, Using = "//body/div[2]/main[1]/div[1]/div[6]/div[4]/div[1]/div[1]/div[4]/div[1]/div[2]/div[2]")]
        private IWebElement TeamsGapIntervalSlider;

        [FindsBy(How = How.XPath, Using = "//body/div[2]/main[1]/div[1]/div[6]/div[4]/div[1]/div[1]/div[4]/label[1]")]
        private IWebElement GapIntervalOutput;

        [FindsBy(How = How.CssSelector, Using = "#chkTeamsExportMasterThreads")]
        private IWebElement TeamsExportMasterThreadsOption;

        [FindsBy(How = How.CssSelector, Using = "#chkTeamsAttachRecipientList")]
        private IWebElement TeamsAttachReceipentListCheckBox;

        [FindsBy(How = How.CssSelector, Using = "#numTeamsRecipientLimit")]
        private IWebElement TeamsRecipientLimitInputField;

        [FindsBy(How = How.CssSelector, Using = "#teamsExportFormatFocusElement")]
        private IWebElement TeamsExportFormatDropDown;

        [FindsBy(How = How.XPath, Using = "//body/div[20]/ul[1]/li")]
        private IList<IWebElement> TeamsExportFormatList;

        [FindsBy(How = How.CssSelector, Using = "#save-settings-btn")]
        private IWebElement TeamsSaveJobSettingsButton;

        [FindsBy(How = How.XPath, Using = "//i[contains(text(),'play_circle_filled')]")]
        private IWebElement RunTeamsJobButton;

        /// <summary>
        /// CreateNewTeamsJob - Method to create a new MS Teams in UC UI project.
        /// </summary>
        /// <param name="projectName"></param>
        /// <returns></returns>
        public bool CreateNewTeamsJob(string projectName)
        {
            try
            {
                System.Threading.Thread.Sleep(2000);
                NewJobButton.Click();
                NewJobNameField.Click();
                NewJobNameField.SendKeys((string)teamsJobSettings.MsTeamsJobName);
                ConversationDropDown.Click();
                TeamsConversationTypeSelect.Click();
                NewJobSourceFilePathField.Click();
                NewJobSourceFilePathField.SendKeys((string)teamsJobSettings.TeamsDataSetPath);
                NewJobCustodianNameField.Click();
                NewJobCustodianNameField.SendKeys((string)teamsJobSettings.CustodianName);
                DescriptionTextAreaField.Click();
                DescriptionTextAreaField.SendKeys("New Teams job created by Automation Script");
                DialogConfirmButton.Click();
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(120));
                wait.Until(driver => IsAlertShown(driver));
                IAlert alert = driver.SwitchTo().Alert();
                alert.Accept();
                System.Threading.Thread.Sleep(10000);
                System.Threading.Thread.Sleep(2000);
                Console.WriteLine("New Chime Job" + (string)teamsJobSettings.MsTeamsJobName + " Created Successfully");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Create a New Chime Job failed due to " + ex.StackTrace);
                return false;
            }
        }

        bool IsAlertShown(IWebDriver driver)
        {
            try
            {
                driver.SwitchTo().Alert();
            }
            catch (NoAlertPresentException e)
            {
                Console.WriteLine("No Alert for job creation: " + e.StackTrace + " waiting for " + TimeSpan.FromSeconds(60));
                return false;
            }
            return true;
        }

        /// <summary>
        /// SaveTeamsJobSettings - Method to save teams job settings to run the Job.
        /// </summary>
        /// <returns></returns>
        public bool SaveTeamsJobSettings()
        {
            try
            {
                System.Threading.Thread.Sleep(2000);
                TeamsTimeZoneDropDown.Click();
                foreach (IWebElement element in TeamsTimeZoneDropDownList)
                {
                    if (element.Text == (string)teamsJobSettings.Timezone)
                    {
                        element.Click();
                        break;
                    }
                }
                if ((bool)teamsJobSettings.AutomaticAssignmentofCustodian == true)
                {
                    TeamsCustodianAutoCheck.Click();
                }
                else
                {
                    TeamsCustodianName.Click();
                    TeamsCustodianName.SendKeys((string)teamsJobSettings.CustodianName);
                    TeamsOwnerName.Click();
                    TeamsOwnerName.SendKeys((string)teamsJobSettings.OwnerDisplayName);
                }
                TeamsControlNumberPrefix.Click();
                TeamsControlNumberPrefix.Clear();
                TeamsControlNumberPrefix.SendKeys((string)teamsJobSettings.Prefix);
                TeamsPrependZeros.Click();
                TeamsPrependZeros.Clear();
                TeamsPrependZeros.SendKeys((string)teamsJobSettings.ZeroPadding);
                TeamsStartingNumber.Click();
                TeamsStartingNumber.Clear();
                TeamsStartingNumber.SendKeys((string)teamsJobSettings.StartingNumber);
                UnitizationExportTab.Click();
                if ((bool)teamsJobSettings.SplitsPerDay == true)
                {
                    TeamsSplitPerDayOption.Click();
                }
                else if((bool)teamsJobSettings.SingleItem==true)
                {
                    TeamsSingleItemOption.Click();
                }
                else if((bool)teamsJobSettings.ConversationGap == true)
                {
                    TeamsConversationGapOption.Click();
                    var PixelsToMove = GetPixelsToMove(TeamsGapIntervalSlider, teamsJobSettings.ConversationGapSlider, 72, 1);
                    Actions SliderAction = new Actions(driver);
                    SliderAction.ClickAndHold(TeamsGapIntervalSlider)
                        .MoveByOffset((-(int)TeamsGapIntervalSlider.Size.Width / 2), 0)
                        .MoveByOffset(PixelsToMove, 0).Release().Perform();
                    //setAttribute(TeamsGapIntervalSlider, "aria-valuenow", (string)teamsJobSettings.ConversationGapSlider);
                    Assert.IsTrue(GapIntervalOutput.Text.Contains((string)teamsJobSettings.ConversationGapSlider));
                }
                if((bool)teamsJobSettings.ExportMasterThreads == true)
                {
                    TeamsExportMasterThreadsOption.Click();
                }
                TeamsRecipientLimitInputField.Click();
                TeamsRecipientLimitInputField.Clear();
                if((int)teamsJobSettings.RecipientLimit is >=100 and <=1000)
                {
                    TeamsRecipientLimitInputField.SendKeys((string)teamsJobSettings.RecipientLimit);
                }
                TeamsSaveJobSettingsButton.Click();
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
                wait.Until(driver => IsAlertShown(driver));
                IAlert alert = driver.SwitchTo().Alert();
                alert.Accept();
                Console.WriteLine("Chime Job Settings saved successfully");
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine("Chime Job Settings failed to apply due to: " + e.StackTrace);
                return false;
            }
        }
        public int GetPixelsToMove(IWebElement Slider, decimal Amount, decimal SliderMax, decimal SliderMin)
        {
            int pixels = 0;
            decimal tempPixels = Slider.Size.Width;
            tempPixels = tempPixels / (SliderMax - SliderMin);
            tempPixels = tempPixels * (Amount - SliderMin);
            pixels = Convert.ToInt32(tempPixels);
            return pixels;
        }
        public void setAttribute(IWebElement element, String attName, String attValue)
        {
            js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("arguments[0].setAttribute(arguments[1], arguments[2]);",
                    element, attName, attValue);
            System.Threading.Thread.Sleep(3000); 
        }

        public bool RunTeamsJob()
        {
            try
            {
                driver.Navigate().Refresh();
                System.Threading.Thread.Sleep(5000);
                //driver.FindElement(By.XPath("//td[contains(text(),'AutomatedChimeJob')]")).Click();
                RunTeamsJobButton.Click();
                System.Threading.Thread.Sleep(5000);
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
                wait.Until(driver => IsAlertShown(driver));
                IAlert alert = driver.SwitchTo().Alert();
                alert.Accept();
                System.Threading.Thread.Sleep(5000);
                wait.Until(driver => driver.FindElement(By.XPath("//a[contains(text(),'Processing')]")));
                return true;
            }
            catch(Exception e)
            {
                Console.WriteLine("Teams Job failed to RUN due to : " + e.StackTrace);
                return false;
            }

        }

    }
}
