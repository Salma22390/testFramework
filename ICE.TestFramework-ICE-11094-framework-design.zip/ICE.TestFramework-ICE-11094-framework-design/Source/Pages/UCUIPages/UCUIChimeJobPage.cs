﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using Newtonsoft.Json;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.IO;
using IceTestAutomation.Utilities;

namespace IceTestAutomation.Pages.UCUIPages
{

    /// <summary>
    /// UCUIChimeJobPage - Page Object Model that initializes web element locators and define methods to act on web elements.
    /// </summary>
    class UCUIChimeJobPage
    {
        private IWebDriver driver;
        private WebDriverWait wait;
        private IJavaScriptExecutor js;
        static string chimeJobSettingsPath = System.IO.Directory.GetParent("../../../").FullName + "/Settings/chimejobsettings.json";
        static string jsonString = File.ReadAllText(chimeJobSettingsPath);
        dynamic chimeJobSettings = JsonConvert.DeserializeObject(jsonString);
        public UCUIChimeJobPage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.Id, Using = "new-job-btn")]
        private IWebElement NewJobButton;

        [FindsBy(How = How.Id, Using = "newJobName")]
        private IWebElement NewJobNameField;

        [FindsBy(How = How.Id, Using = "conversionTypeFocusElement")]
        private IWebElement ConversationDropDown;

        [FindsBy(How = How.XPath, Using = "//li[contains(text(),'Chime')]")]
        private IWebElement ChimeConversationTypeSelect;

        [FindsBy(How = How.Id, Using = "newJobSourceFilePath")]
        private IWebElement NewJobSourceFilePathField;

        [FindsBy(How = How.Id, Using = "newJobCustodianName")]
        private IWebElement NewJobCustodianNameField;

        [FindsBy(How = How.Id, Using = "descriptionTextarea")]
        private IWebElement DescriptionTextAreaField;

        [FindsBy(How = How.Id, Using = "dialog-confirm")]
        private IWebElement DialogConfirmButton;

        // Settings Part Element Locators
        [FindsBy(How =How.CssSelector, Using = "#chimeTimezoneFocusElement")]
        private IWebElement ChimeTimeZoneDropDown;

        [FindsBy(How = How.XPath, Using = "//ul[@id='chimeTimezonesList']/li")]
        private IList<IWebElement> ChimeTimeZoneDropDownList;

        [FindsBy(How = How.CssSelector, Using = "#txtChimeCustodianName")]
        private IWebElement ChimeCustodianName;

        [FindsBy(How = How.CssSelector, Using = "#txtChimeControlNumberPrefix")]
        private IWebElement ChimeControlNumberPrefix;

        [FindsBy(How = How.CssSelector, Using = "#numChimePrependZeros")]
        private IWebElement ChimePrependZeros;

        [FindsBy(How = How.CssSelector, Using = "#numChimeStartingNumber")]
        private IWebElement ChimeStartingNumber;

        [FindsBy(How = How.XPath, Using = "//body/div[2]/main[1]/div[1]/div[3]/div[2]/div[1]/div[1]/div[1]/button[2]/span[3]")]
        private IWebElement UnitizationExportTab;

        [FindsBy(How = How.CssSelector, Using = "#chimeOptSplitPerDay")]
        private IWebElement ChimeSplitPerDayOption;

        [FindsBy(How = How.CssSelector, Using = "#chimeOptSingleItem")]
        private IWebElement ChimeSingleItemOption;

        [FindsBy(How = How.CssSelector, Using = "#chimeOptGapAnalysis")]
        private IWebElement ChimeConversationGapOption;

        [FindsBy(How = How.Id, Using = "chimeGapIntervalMdcSlider")]
        private IWebElement chimeGapIntervalSlider;

        [FindsBy(How = How.CssSelector, Using = ".uc-chat-gap-interval-slider .mdc-slider__track")]
        private IWebElement ChimeGapSlider;

        [FindsBy(How = How.CssSelector, Using = "#chkChimeExportMasterThreads")]
        private IWebElement ChimeExportMasterThreadsOption;

        [FindsBy(How = How.CssSelector, Using = "#chkChimeAttachRecipientList")]
        private IWebElement ChimeAttachReceipentListCheckBox;

        [FindsBy(How = How.CssSelector, Using = "#numChimeRecipientLimit")]
        private IWebElement ChimeRecipientLimitInputField;

        [FindsBy(How = How.CssSelector, Using = "#chimeExportFormatFocusElement")]
        private IWebElement ChimeExportFormatDropDown;

        [FindsBy(How = How.XPath, Using = "//body/div[21]/ul[1]/li")]
        private IList<IWebElement> ChimeExportFormatList;

        [FindsBy(How = How.CssSelector, Using = "#save-settings-btn")]
        private IWebElement ChimeSaveJobSettingsButton;

        [FindsBy(How = How.XPath, Using = "//i[contains(text(),'play_circle_filled')]")]
        private IWebElement RunChimeJobButton;

        [FindsBy(How = How.CssSelector, Using = "label > input")]
        private IWebElement ProjectSearchField;

        /// <summary>
        /// CreateNewChimeJob() - Method that creates a new chime job
        /// </summary>
        /// <param name="projectName"></param>
        /// <returns></returns>
        public bool CreateNewChimeJob(string projectName)
        {
            try
            {
                System.Threading.Thread.Sleep(2000);
                NewJobButton.Click();
                NewJobNameField.Click();
                NewJobNameField.SendKeys((string)chimeJobSettings.ChimeJobName);
                ConversationDropDown.Click();
                ChimeConversationTypeSelect.Click();
                NewJobSourceFilePathField.Click();
                NewJobSourceFilePathField.SendKeys((string)chimeJobSettings.ChimeDataSetPath);
                NewJobCustodianNameField.Click();
                NewJobCustodianNameField.SendKeys((string)chimeJobSettings.CustodianName);
                DescriptionTextAreaField.Click();
                DescriptionTextAreaField.SendKeys("New Chime job created by Automation Script");
                DialogConfirmButton.Click();
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(120));
                wait.Until(driver => IsAlertShown(driver));
                IAlert alert = driver.SwitchTo().Alert();
                alert.Accept();
                System.Threading.Thread.Sleep(10000);
                System.Threading.Thread.Sleep(2000);
                Console.WriteLine("New Chime Job" + (string)chimeJobSettings.ChimeJobName + " Created Successfully");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Create a New Chime Job failed due to " + ex.StackTrace);
                return false;
            }
        }

        bool IsAlertShown(IWebDriver driver)
        {
            try
            {
                driver.SwitchTo().Alert();
            }
            catch (NoAlertPresentException e)
            {
                Console.WriteLine("No Alert for job creation: " + e.StackTrace + " waiting for " + TimeSpan.FromSeconds(60));
                return false;
            }
            return true;
        }

        /// <summary>
        /// SaveChimeJobSettings() - Method to save the job settings for new chime job.
        /// </summary>
        /// <returns></returns>
        public bool SaveChimeJobSettings()
        {
            try
            {
                System.Threading.Thread.Sleep(2000);
                ChimeTimeZoneDropDown.Click();
                foreach (IWebElement element in ChimeTimeZoneDropDownList)
                {
                    if (element.Text == (string)chimeJobSettings.Timezone)
                    {
                        element.Click();
                        break;
                    }
                }
                ChimeControlNumberPrefix.Click();
                ChimeControlNumberPrefix.Clear();
                ChimeControlNumberPrefix.SendKeys((string)chimeJobSettings.Prefix);
                ChimePrependZeros.Click();
                ChimePrependZeros.Clear();
                ChimePrependZeros.SendKeys((string)chimeJobSettings.ZeroPadding);
                ChimeStartingNumber.Click();
                ChimeStartingNumber.Clear();
                ChimeStartingNumber.SendKeys((string)chimeJobSettings.StartingNumber);
                UnitizationExportTab.Click();
                if ((bool)chimeJobSettings.SplitsPerDay == true)
                {
                    ChimeSplitPerDayOption.Click();
                }
                else if((bool)chimeJobSettings.SingleItem==true)
                {
                    ChimeSingleItemOption.Click();
                }
                else if((bool)chimeJobSettings.ConversationGap == true)
                {
                    ChimeConversationGapOption.Click();
                    setAttribute(chimeGapIntervalSlider, "aria-valuenow", (string)chimeJobSettings.ConversationGapSlider);
                    Assert.IsTrue(driver.FindElement(By.Id("chimeSliderLabel")).Text.Contains((string)chimeJobSettings.ConversationGapSlider));
                }
                if((bool)chimeJobSettings.ExportMasterThreads == true)
                {
                    ChimeExportMasterThreadsOption.Click();
                }
                ChimeRecipientLimitInputField.Click();
                ChimeRecipientLimitInputField.Clear();
                if((int)chimeJobSettings.RecipientLimit is >=100 and <=1000)
                {
                    ChimeRecipientLimitInputField.SendKeys((string)chimeJobSettings.RecipientLimit);
                }
                ChimeSaveJobSettingsButton.Click();
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
                wait.Until(driver => IsAlertShown(driver));
                IAlert alert = driver.SwitchTo().Alert();
                alert.Accept();
                Console.WriteLine("Chime Job Settings saved successfully");
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine("Chime Job Settings failed to apply due to: " + e.StackTrace);
                return false;
            }
        }
        public void setAttribute(IWebElement element, String attName, String attValue)
        {
            js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("arguments[0].setAttribute(arguments[1], arguments[2]);",
                    element, attName, attValue);
            System.Threading.Thread.Sleep(3000); 
        }

        /// <summary>
        /// RunChimeJob() - Method to run new chime job.
        /// </summary>
        /// <returns></returns>
        public bool RunChimeJob()
        {
            try
            {
                driver.Navigate().Refresh();
                System.Threading.Thread.Sleep(5000);
                //driver.FindElement(By.XPath("//td[contains(text(),'AutomatedChimeJob')]")).Click();
                RunChimeJobButton.Click();
                System.Threading.Thread.Sleep(5000);
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
                wait.Until(driver => IsAlertShown(driver));
                IAlert alert = driver.SwitchTo().Alert();
                alert.Accept();
                System.Threading.Thread.Sleep(5000);
                wait.Until(driver => driver.FindElement(By.XPath("//a[contains(text(),'Processing')]")));
                return true;
            }
            catch(Exception e)
            {
                Console.WriteLine("Chime Job failed to RUN due to : " + e.StackTrace);
                return false;
            }

        }

    }
}
