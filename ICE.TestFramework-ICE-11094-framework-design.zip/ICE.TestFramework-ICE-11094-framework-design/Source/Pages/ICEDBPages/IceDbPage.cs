﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Common;
using System.Data;
using System.IO;

namespace IceTestAutomation.Pages.ICEDBPages
{

    /// <summary>
    /// IceDbPage - Class that defines methods for ICE and its project instance databases.
    /// </summary>
    class IceDbPage
    {
        private SqlConnection sqlConnection;
        public IceDbPage(String connectionInfo)
        {
            sqlConnection = new SqlConnection(connectionInfo);
        }

        /// <summary>
        /// executeSqlScript() - Method that executes SQL script
        /// </summary>
        /// <param name="SqlScript"></param>
        public void executeSqlScript(string SqlScript)
        {
            /// TBD
        }

        /// <summary>
        /// executeSqlQueryWithoutOutput() - Method that executes SQL query
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        public bool executeSqlQueryWithoutOutput(string sqlQuery)
        {
            int result = 0;
            using (SqlCommand command = new SqlCommand(sqlQuery, sqlConnection))
            {
                sqlConnection.Open();
                result = command.ExecuteNonQuery();
            }
            if (result != 0)
                return true;
            return false;
        }

        /// <summary>
        /// executeSqlQueryWithOutput() - Method that executes SQL Query without output
        /// </summary>
        /// <param name="sqlQuery"></param>
        public void executeSqlQueryWithOutput(string sqlQuery)
        {
            try
            {
                DataSet dataSet = new DataSet();
                StreamWriter swExtLogFile = new StreamWriter(System.IO.Directory.GetParent("../../../").FullName + "/SqlResults/Result" + DateTime.Now.ToString("ddMMyyyy-HHmmss") + ".txt", true);
                using (SqlCommand command = new SqlCommand(sqlQuery, sqlConnection))
                {
                    //command.CommandType = CommandType.StoredProcedure;
                    sqlConnection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(dataSet);
                    //dataset = command.ExecuteNonQuery();
                }
                if (dataSet.Tables.Count > 0)
                {
                    foreach (DataTable table in dataSet.Tables)
                    {
                        int i;
                        foreach (DataRow row in table.Rows)
                        {
                            object[] array = row.ItemArray;
                            for (i = 0; i < array.Length - 1; i++)
                            {
                                swExtLogFile.Write(array[i].ToString() + " | ");
                            }
                            swExtLogFile.WriteLine(array[i].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
