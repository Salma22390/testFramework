﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceTestAutomation.IceApiClasses
{
    /// <summary>
    /// ProjectApiClass - POCO class that is used for API request and response serialization and deserialization respectively.
    /// </summary>
    public class ProjectApiClass
    {
        public class GetProjectApiClass
        {
            public int id { get; set; }
            public string? uuid { get; set; }
            public string? name { get; set; }
            public string? databaseName { get; set; }
            public string? description { get; set; }
            public DateTime createdOnUtc { get; set; }
            public string? createdFrom { get; set; }
            public string? createdBy { get; set; }
            public string? number { get; set; }
            public string? client { get; set; }
            public string? workflow { get; set; }
            public int jobCount { get; set; }
            public string? lastOpenedBy { get; set; }
            public DateTime? lastOpenedOnUtc { get; set; }
            public string? lastUpdatedBy { get; set; }
            public DateTime? lastUpdatedOnUtc { get; set; }
        }
    }
}
