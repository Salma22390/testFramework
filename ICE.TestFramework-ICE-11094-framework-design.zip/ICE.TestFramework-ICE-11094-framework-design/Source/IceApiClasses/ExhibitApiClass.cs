﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceTestAutomation.IceApiClasses
{
    /// <summary>
    /// ExhibitApiClass - POCO class that is used for API request and response serialization and deserialization respectively.
    /// </summary>
    public class ExhibitApiClass
    {
        public class Settings
        {
        }

        public class Link
        {
            public string Rel { get; set; }
            public string Href { get; set; }
            public string Action { get; set; }
        }

        public class GetExhibitApiClass
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string Description { get; set; }
            public string UncPath { get; set; }
            public string Status { get; set; }
            public int CustodianId { get; set; }
            public string CustodianName { get; set; }
            public string CreatedFrom { get; set; }
            public string CreatedBy { get; set; }
            public DateTime CreatedOnUtc { get; set; }
            public DateTime ValidDateRangeStart { get; set; }
            public DateTime ValidDateRangeEnd { get; set; }
            public Settings Settings { get; set; }
            public List<Link> Links { get; set; }
        }

    }
}
