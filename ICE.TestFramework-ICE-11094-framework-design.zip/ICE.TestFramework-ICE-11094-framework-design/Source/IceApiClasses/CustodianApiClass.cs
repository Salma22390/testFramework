﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceTestAutomation.IceApiClasses
{
    /// <summary>
    /// CustodianApiClass - POCO class that is used for API request and response serialization and deserialization respectively.
    /// </summary>
    public class CustodianApiClass
    {
        public class Link
        {
            public string rel { get; set; }
            public string href { get; set; }
            public string action { get; set; }
        }

        public class GetCustodianApiClass
        {
            public int id { get; set; }
            public string name { get; set; }
            public List<Link> links { get; set; }
        }
    }
}
