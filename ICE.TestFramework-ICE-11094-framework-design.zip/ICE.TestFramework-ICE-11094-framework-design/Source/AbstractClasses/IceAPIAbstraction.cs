﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using IceTestAutomation.Interfaces;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceTestAutomation.AbstractClasses
{
    /// <summary>
    /// IceAPIAbstraction - Class that defines or implements the IceAPIClient interface methods.
    /// </summary>
    public class IceAPIAbstraction : IceAPIClient
    {
        IRestRequest IceAPIClient.createDeleteRequest(string endPoint)
        {
            return new RestRequest(endPoint, Method.DELETE)
                .AddHeader("Accept", "application/json");
        }

        IRestRequest IceAPIClient.createGetRequest(string endPoint)
        {
            return new RestRequest(endPoint, Method.GET)
                .AddHeader("Accept", "application/json");
        }

        IRestRequest IceAPIClient.createPatchRequest(string endPoint, string? jsonString)
        {
            return new RestRequest(endPoint, Method.PATCH)
                .AddHeader("Accept", "application/json")
                .AddParameter("application/json", jsonString, ParameterType.RequestBody);
        }

        IRestRequest IceAPIClient.createPostRequest(string endPoint, string? jsonString)
        {
            return new RestRequest(endPoint, Method.POST)
                .AddHeader("Accept", "application/json")
                .AddParameter("application/json", jsonString, ParameterType.RequestBody);
        }

        IRestRequest IceAPIClient.createPutRequest(string endPoint, string? jsonString)
        {
            return new RestRequest(endPoint, Method.PUT)
                .AddHeader("Accept", "application/json")
                .AddParameter("application/json", jsonString, ParameterType.RequestBody);
        }

        IRestResponse IceAPIClient.GetResponse(IRestClient restClient, IRestRequest restRequest)
        {
            return restClient.Execute(restRequest);
        }

        RestClient IceAPIClient.initializeEndpoint()
        {
            return new RestClient();
        }
    }
}
