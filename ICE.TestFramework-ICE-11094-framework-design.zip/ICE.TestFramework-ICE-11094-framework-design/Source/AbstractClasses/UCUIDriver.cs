﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */
using IceTestAutomation.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDriverManager.DriverConfigs.Impl;

namespace IceTestAutomation.AbstractClasses
{
    /// <summary>
    /// UCUIDriver - Class that defines or implements the UCUIClient interface methods.
    /// </summary>
    public class UCUIDriver : UCUIClient
    {
        public WebDriver initBrowser()
        {
            new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig(), "97.0.4692.71");
            return new ChromeDriver();
        }
    }
}
