﻿/**
 * Unpublished Work. Copyrights© 2022 CONSILIO
 * All rights reserved.
 * CONSILIO RESTRICTED CONFIDENTIAL
 * This document is restricted, confidential and proprietary to Consilio, and is to be
 * used only by and disclosed only to those within Consilio with a need to know.
 * DO NOT COPY OR FORWARD INTERNALLY OR RELEASE outside Consilio. 
 */

/*
 * To generate a QA report for failure occured during test run.
 */
PRINT 'Report Date: ' + CAST(GETDATE() AS NVARCHAR(MAX))
PRINT 'Report By:   ' + SYSTEM_USER
PRINT '--------------------------------------'


DECLARE @icedb_version VARCHAR(64) = (SELECT property_value FROM ice_db.dbo.properties WHERE property_name = 'template_version')
DECLARE @template_version VARCHAR(64) = (SELECT property_value FROM dbo.properties WHERE property_name = 'template_version')



IF @icedb_version <> @template_version 
BEGIN

  EXEC PRINT_HEADER '  ICEDB DETAILS  ' 
  PRINT 'Version:   ' + @icedb_version
  PRINT ''

  PRINT 'WARNING: ice_db version DOES NOT MATCH project template. Worker requests will be ignored.'
  PRINT ''
END


EXEC PRINT_HEADER '  PROJECT DETAILS '

DECLARE @workflow VARCHAR(64) = (SELECT property_value FROM dbo.properties WHERE property_name = 'workflow')
DECLARE @project_id INT = CAST(REPLACE(DB_NAME(), 'ICE', '') AS INT)

PRINT 'Workflow:   ' + @workflow
PRINT 'Database:   ' + DB_NAME()
PRINT 'Version:    ' + @template_version
PRINT 'Server:     ' + @@SERVERNAME
PRINT 'Project Id: ' + CAST(@project_id AS VARCHAR(16))



EXEC usr.[Project Properties]


EXEC PRINT_HEADER 'EXHIBITS'
EXEC usr.[Data Source Summary]


EXEC PRINT_HEADER 'ROUTING SUMMARY'
EXEC usr.[Routing Summary]


EXEC PRINT_HEADER 'EXCEPTIONS'
EXEC gui.get_exceptions_per_code
EXEC gui.get_exceptions_per_task


EXEC PRINT_HEADER 'SERVICE BROKER DIAGNOSTICS'
EXEC ice.db_run_diagnostics


EXEC PRINT_HEADER 'CRACKING LOG'
SELECT event_time, event_message FROM dbo.event_log ORDER BY event_id




IF @workflow = 'Universal Converter'
BEGIN

EXEC PRINT_HEADER 'UNIVERSAL CONVERTER JOBS'

SELECT FORMATMESSAGE ( '%s/projects/%i/job', ice_db.ice.get_property_value ( 'uc_web_interface' ), CAST(RIGHT(DB_NAME(),6) AS INT))

SELECT job_id
     , CAST(JSON_VALUE(job_config, '$.name') AS NVARCHAR(24)) [job_name]
	 , parent_job_id
     , exhibit_id
     , CAST(type.job_type_name AS VARCHAR(16)) [job_type_name]
     , dataset_group
     , exhibit_status
     , CAST(stage.name AS varchar(16)) [stage]
	 -- "Auto" status triggers uc job and export automatically
     , CAST((SELECT ice.group_concat(st.name, ';', 1) FROM uc.job_status st WHERE job.status & st.flag > 0) AS VARCHAR(32)) status
     --, job_config
     
FROM uc.job
LEFT JOIN uc.job_type type ON type.job_type_id = job.job_type_id
LEFT JOIN uc.job_stage stage ON  stage.id = job.stage



DECLARE jobs_cursor CURSOR FAST_FORWARD LOCAL
FOR
SELECT job_id FROM uc.job

DECLARE @job_id INT

OPEN jobs_cursor

WHILE (1 = 1)
BEGIN

    FETCH NEXT FROM jobs_cursor
    INTO @job_id
	
	IF @@FETCH_STATUS <> 0 
		BREAK;


	EXEC PRINT_HEADER 'JOB ID: ', @job_id

DECLARE 
		@name NVARCHAR(MAX)
		, @conversionType NVARCHAR(MAX)
		, @jobTypeID NVARCHAR(MAX)

		, @description NVARCHAR(MAX)
		, @sourceFilePath NVARCHAR(MAX)
		, @phoneOrigin NVARCHAR(MAX)
		, @phoneNumber NVARCHAR(MAX)
		, @ownerId NVARCHAR(MAX)
		, @exhibitReference NVARCHAR(MAX)

		, @outputDirectory NVARCHAR(MAX)

	SELECT 
		@name = JSON_VALUE(job_config, '$.name')
		, @conversionType = JSON_VALUE(job_config, '$.conversionType') 
                , @description = JSON_VALUE(job_config, '$.description') 
		, @sourceFilePath = JSON_VALUE(job_config, '$.sourceFilePath') 
		, @phoneOrigin = JSON_VALUE(job_config, '$.phoneOrigin') 
		, @phoneNumber = JSON_VALUE(job_config, '$.phoneNumber') 
		, @ownerId = JSON_VALUE(job_config, '$.ownerId') 
		, @exhibitReference = JSON_VALUE(job_config, '$.exhibitReference') 		

		, @outputDirectory = JSON_VALUE(job_config, '$.exportSettings.outputDirectory') 
	FROM uc.job WHERE uc.job.job_id = @job_id


	PRINT ''
	PRINT 'Job Name:                 ' + @name
	PRINT 'Job Conversion Type:      ' + @conversionType
        PRINT 'Job Description:          ' + @description 
	PRINT 'Job Source File Path:     ' + @sourceFilePath 
	PRINT 'Job Phone Origin:         ' + @phoneOrigin 
	PRINT 'Job Phone Number:         ' + @phoneNumber 
	PRINT 'Job Owner Id:             ' + @ownerId 
	PRINT 'Job Exhibit Reference:    ' + @exhibitReference 


	PRINT 'Export Output Directory:  ' + @outputDirectory


	PRINT 'Job Log:'
	
	SELECT timestamp, event_message FROM uc.job_log WHERE job_id = @job_id

END

CLOSE jobs_cursor;
DEALLOCATE jobs_cursor;


END

--DROP PROCEDURE IF EXISTS PRINT_HEADER
